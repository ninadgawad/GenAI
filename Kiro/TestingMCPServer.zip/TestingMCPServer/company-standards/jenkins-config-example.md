# Jenkins Configuration for Playwright Testing

## Overview
This document provides comprehensive Jenkins configuration examples for running Playwright tests in a corporate environment with company standards compliance.

## Jenkins Server Setup

### Required Plugins
```groovy
// Install these plugins in Jenkins
plugins {
    id 'nodejs' version '1.5.1'
    id 'pipeline-stage-view' version '2.25'
    id 'blueocean' version '1.25.2'
    id 'html-publisher' version '1.31'
    id 'junit' version '1.60'
    id 'slack' version '2.49'
    id 'docker-pipeline' version '1.28'
}
```

### Global Tool Configuration
```bash
# Node.js installations (Manage Jenkins > Global Tool Configuration)
Name: NodeJS-18
Version: 18.19.0
Global npm packages: playwright@latest

Name: NodeJS-20
Version: 20.10.0
Global npm packages: playwright@latest
```

### System Configuration
```groovy
// Jenkins system configuration
pipeline {
    agent {
        label 'linux && docker'
    }
    
    environment {
        // Global environment variables
        NODE_OPTIONS = '--max-old-space-size=4096'
        PLAYWRIGHT_BROWSERS_PATH = '$WORKSPACE/browsers'
        CI = 'true'
        JENKINS_CI = 'true'
    }
}
```

## Complete Jenkinsfile Example

### Production-Ready Jenkinsfile
```groovy
pipeline {
    agent {
        kubernetes {
            yaml """
                apiVersion: v1
                kind: Pod
                spec:
                  containers:
                  - name: node
                    image: node:18-alpine
                    command:
                    - cat
                    tty: true
                    resources:
                      requests:
                        memory: "2Gi"
                        cpu: "1000m"
                      limits:
                        memory: "4Gi"
                        cpu: "2000m"
                  - name: docker
                    image: docker:dind
                    securityContext:
                      privileged: true
                    volumeMounts:
                    - name: docker-sock
                      mountPath: /var/run/docker.sock
                  volumes:
                  - name: docker-sock
                    hostPath:
                      path: /var/run/docker.sock
            """
        }
    }
    
    environment {
        NODE_VERSION = '18'
        PLAYWRIGHT_BROWSERS_PATH = '$WORKSPACE/browsers'
        CI = 'true'
        JENKINS_CI = 'true'
        
        // Company-specific environment variables
        COMPANY_TEST_ENV = 'jenkins'
        SECURITY_SCAN_ENABLED = 'true'
        PERFORMANCE_BUDGET = '3000'
        
        // Credentials
        SLACK_TOKEN = credentials('slack-bot-token')
        SONAR_TOKEN = credentials('sonar-token')
        CODECOV_TOKEN = credentials('codecov-token')
    }
    
    options {
        timeout(time: 45, unit: 'MINUTES')
        retry(2)
        skipStagesAfterUnstable()
        buildDiscarder(logRotator(numToKeepStr: '10'))
        timestamps()
        ansiColor('xterm')
    }
    
    triggers {
        // Nightly builds
        cron('H 2 * * *')
        
        // Poll SCM every 5 minutes during business hours
        pollSCM('H/5 8-18 * * 1-5')
    }
    
    stages {
        stage('Checkout & Setup') {
            parallel {
                stage('Checkout Code') {
                    steps {
                        container('node') {
                            checkout scm
                            script {
                                env.GIT_COMMIT_SHORT = sh(
                                    script: "git rev-parse --short HEAD",
                                    returnStdout: true
                                ).trim()
                                env.BUILD_TIMESTAMP = sh(
                                    script: "date +%Y%m%d-%H%M%S",
                                    returnStdout: true
                                ).trim()
                            }
                        }
                    }
                }
                
                stage('Environment Info') {
                    steps {
                        container('node') {
                            sh '''
                                echo "=== Environment Information ==="
                                echo "Node.js Version: $(node --version)"
                                echo "NPM Version: $(npm --version)"
                                echo "Git Commit: $GIT_COMMIT_SHORT"
                                echo "Build Number: $BUILD_NUMBER"
                                echo "Workspace: $WORKSPACE"
                                echo "Available Memory: $(free -h)"
                                echo "Available Disk: $(df -h)"
                            '''
                        }
                    }
                }
            }
        }
        
        stage('Dependencies & Setup') {
            parallel {
                stage('Install Dependencies') {
                    steps {
                        container('node') {
                            sh '''
                                # Clean install with audit
                                npm ci --prefer-offline --no-audit --cache .npm
                                
                                # Verify package integrity
                                npm audit --audit-level moderate
                                
                                # Install Playwright browsers
                                npx playwright install --with-deps chromium firefox webkit
                                
                                # Verify Playwright installation
                                npx playwright --version
                            '''
                        }
                    }
                }
                
                stage('Security Scan') {
                    when {
                        environment name: 'SECURITY_SCAN_ENABLED', value: 'true'
                    }
                    steps {
                        container('node') {
                            sh '''
                                # Run security audit
                                npm audit --json > npm-audit.json || true
                                
                                # Run Snyk security scan (if available)
                                if command -v snyk &> /dev/null; then
                                    snyk test --json > snyk-report.json || true
                                fi
                            '''
                        }
                    }
                    post {
                        always {
                            archiveArtifacts artifacts: '*-audit.json, *-report.json', allowEmptyArchive: true
                        }
                    }
                }
            }
        }
        
        stage('Code Quality') {
            parallel {
                stage('Lint') {
                    steps {
                        container('node') {
                            sh '''
                                # ESLint with company rules
                                npm run lint -- --format junit --output-file lint-results.xml
                                npm run lint -- --format html --output-file lint-results.html
                            '''
                        }
                    }
                    post {
                        always {
                            publishTestResults testResultsPattern: 'lint-results.xml'
                            publishHTML([
                                allowMissing: false,
                                alwaysLinkToLastBuild: true,
                                keepAll: true,
                                reportDir: '.',
                                reportFiles: 'lint-results.html',
                                reportName: 'ESLint Report'
                            ])
                        }
                    }
                }
                
                stage('Type Check') {
                    steps {
                        container('node') {
                            sh '''
                                # TypeScript type checking
                                npm run type-check
                                
                                # Generate type coverage report
                                if npm list type-coverage &> /dev/null; then
                                    npx type-coverage --detail --strict
                                fi
                            '''
                        }
                    }
                }
            }
        }
        
        stage('Unit Tests') {
            steps {
                container('node') {
                    sh '''
                        # Run unit tests with coverage
                        npm run test:unit -- --coverage --watchAll=false --ci --testResultsProcessor=jest-junit
                        
                        # Generate coverage reports
                        npm run test:unit -- --coverage --coverageReporters=lcov --coverageReporters=html --coverageReporters=cobertura
                    '''
                }
            }
            post {
                always {
                    publishTestResults testResultsPattern: 'junit.xml'
                    publishHTML([
                        allowMissing: false,
                        alwaysLinkToLastBuild: true,
                        keepAll: true,
                        reportDir: 'coverage',
                        reportFiles: 'index.html',
                        reportName: 'Coverage Report'
                    ])
                }
            }
        }
        
        stage('Build Application') {
            steps {
                container('node') {
                    sh '''
                        # Build the application
                        npm run build
                        
                        # Verify build output
                        ls -la dist/
                    '''
                }
            }
            post {
                success {
                    archiveArtifacts artifacts: 'dist/**/*', fingerprint: true
                }
            }
        }
        
        stage('E2E Tests') {
            parallel {
                stage('Chrome Tests') {
                    steps {
                        container('node') {
                            sh '''
                                # Start application in background
                                npm start &
                                APP_PID=$!
                                echo $APP_PID > app-chrome.pid
                                
                                # Wait for application to be ready
                                timeout 120 bash -c 'until curl -f http://localhost:3000; do sleep 2; done'
                                
                                # Run Chrome tests
                                npm run test:e2e:ci -- --project=chromium --workers=2 --reporter=junit --output-dir=test-results/chrome
                            '''
                        }
                    }
                    post {
                        always {
                            sh '''
                                if [ -f app-chrome.pid ]; then
                                    kill $(cat app-chrome.pid) || true
                                    rm app-chrome.pid
                                fi
                            '''
                            publishTestResults testResultsPattern: 'test-results/chrome/junit.xml'
                            archiveArtifacts artifacts: 'test-results/chrome/**/*', allowEmptyArchive: true
                        }
                    }
                }
                
                stage('Firefox Tests') {
                    steps {
                        container('node') {
                            sh '''
                                # Start application on different port
                                PORT=3001 npm start &
                                APP_PID=$!
                                echo $APP_PID > app-firefox.pid
                                
                                # Wait for application
                                timeout 120 bash -c 'until curl -f http://localhost:3001; do sleep 2; done'
                                
                                # Run Firefox tests
                                BASE_URL=http://localhost:3001 npm run test:e2e:ci -- --project=firefox --workers=2 --reporter=junit --output-dir=test-results/firefox
                            '''
                        }
                    }
                    post {
                        always {
                            sh '''
                                if [ -f app-firefox.pid ]; then
                                    kill $(cat app-firefox.pid) || true
                                    rm app-firefox.pid
                                fi
                            '''
                            publishTestResults testResultsPattern: 'test-results/firefox/junit.xml'
                            archiveArtifacts artifacts: 'test-results/firefox/**/*', allowEmptyArchive: true
                        }
                    }
                }
            }
            post {
                always {
                    // Combine all test reports
                    sh '''
                        mkdir -p combined-reports
                        npx playwright merge-reports --reporter=html test-results/*/
                        mv playwright-report combined-reports/
                    '''
                    
                    publishHTML([
                        allowMissing: false,
                        alwaysLinkToLastBuild: true,
                        keepAll: true,
                        reportDir: 'combined-reports/playwright-report',
                        reportFiles: 'index.html',
                        reportName: 'Playwright Test Report'
                    ])
                }
            }
        }
        
        stage('Deploy to Staging') {
            when {
                branch 'develop'
            }
            steps {
                container('docker') {
                    sh '''
                        # Build Docker image
                        docker build -t react-app:$BUILD_NUMBER .
                        
                        # Deploy to staging
                        echo "Deploying to staging environment"
                    '''
                }
            }
        }
        
        stage('Deploy to Production') {
            when {
                branch 'main'
            }
            steps {
                script {
                    timeout(time: 5, unit: 'MINUTES') {
                        input message: 'Deploy to production?', ok: 'Deploy',
                              submitterParameter: 'DEPLOYER'
                    }
                }
                container('docker') {
                    sh '''
                        echo "Deploying to production environment"
                        echo "Deployed by: $DEPLOYER"
                    '''
                }
            }
        }
    }
    
    post {
        always {
            cleanWs()
            
            script {
                def status = currentBuild.result ?: 'SUCCESS'
                def color = status == 'SUCCESS' ? 'good' : 'danger'
                def message = """
                    *${env.JOB_NAME}* - Build #${env.BUILD_NUMBER}
                    Status: ${status}
                    Branch: ${env.BRANCH_NAME}
                    Commit: ${env.GIT_COMMIT_SHORT}
                    Duration: ${currentBuild.durationString}
                    
                    <${env.BUILD_URL}|View Build>
                    <${env.BUILD_URL}Playwright_20Test_20Report/|View Test Report>
                """
                
                slackSend(
                    channel: '#ci-cd-notifications',
                    color: color,
                    message: message,
                    token: env.SLACK_TOKEN
                )
            }
        }
    }
}
```

## Customization Ideas for Different CI/CD Platforms

### 1. Platform-Specific Configurations

#### Jenkins Shared Libraries
```groovy
// vars/playwrightTest.groovy
def call(Map config) {
    pipeline {
        agent any
        stages {
            stage('Test') {
                steps {
                    script {
                        def browsers = config.browsers ?: ['chromium', 'firefox']
                        def workers = config.workers ?: 4
                        
                        browsers.each { browser ->
                            sh "npm run test:e2e:ci -- --project=${browser} --workers=${workers}"
                        }
                    }
                }
            }
        }
    }
}

// Usage in Jenkinsfile
playwrightTest([
    browsers: ['chromium', 'firefox', 'webkit'],
    workers: 6,
    timeout: 45
])
```

#### GitLab CI Templates
```yaml
# .gitlab/ci/playwright.yml
.playwright_template:
  image: node:18
  variables:
    PLAYWRIGHT_BROWSERS_PATH: "$CI_PROJECT_DIR/browsers"
  before_script:
    - npm ci
    - npx playwright install --with-deps
  script:
    - npm run test:e2e:ci -- --project=$BROWSER --workers=$WORKERS
  artifacts:
    when: always
    reports:
      junit: test-results/junit.xml
    paths:
      - playwright-report/
      - test-results/

# Usage
chrome_tests:
  extends: .playwright_template
  variables:
    BROWSER: "chromium"
    WORKERS: "4"
```

### 2. Environment-Specific Customizations

#### Development Environment
```yaml
# .env.development
NODE_ENV=development
BASE_URL=http://localhost:3000
HEADLESS=false
SLOW_MO=100
SCREENSHOT_ON_FAILURE=true
VIDEO_ON_FAILURE=false
```

#### Staging Environment
```yaml
# .env.staging
NODE_ENV=staging
BASE_URL=https://staging.yourapp.com
HEADLESS=true
PARALLEL_WORKERS=2
RETRIES=1
SCREENSHOT_ON_FAILURE=true
VIDEO_ON_FAILURE=true
```

#### Production Environment
```yaml
# .env.production
NODE_ENV=production
BASE_URL=https://yourapp.com
HEADLESS=true
PARALLEL_WORKERS=1
RETRIES=2
SCREENSHOT_ON_FAILURE=true
VIDEO_ON_FAILURE=true
TRACE_ON_RETRY=true
```

### 3. Team-Specific Configurations

#### Frontend Team Configuration
```json
{
  "browsers": ["chromium", "firefox", "webkit"],
  "testTypes": ["component", "page", "navigation"],
  "coverage": {
    "threshold": 80,
    "includeUntested": true
  },
  "accessibility": {
    "enabled": true,
    "standard": "WCAG2AA"
  }
}
```

#### QA Team Configuration
```json
{
  "browsers": ["chromium", "firefox", "webkit", "mobile-chrome", "mobile-safari"],
  "testTypes": ["e2e", "integration", "performance"],
  "reporting": {
    "detailed": true,
    "screenshots": "always",
    "videos": "on-failure"
  },
  "crossBrowser": true
}
```

### 4. Project-Type Specific Templates

#### E-commerce Application
```yaml
# playwright.config.ecommerce.ts
export default defineConfig({
  projects: [
    { name: 'checkout-flow', testDir: './tests/checkout' },
    { name: 'product-catalog', testDir: './tests/catalog' },
    { name: 'user-account', testDir: './tests/account' },
    { name: 'payment-processing', testDir: './tests/payment' }
  ],
  use: {
    baseURL: process.env.BASE_URL,
    extraHTTPHeaders: {
      'X-Test-Suite': 'ecommerce'
    }
  }
});
```

#### SaaS Dashboard
```yaml
# playwright.config.saas.ts
export default defineConfig({
  projects: [
    { name: 'authentication', testDir: './tests/auth' },
    { name: 'dashboard', testDir: './tests/dashboard' },
    { name: 'settings', testDir: './tests/settings' },
    { name: 'billing', testDir: './tests/billing' }
  ],
  use: {
    baseURL: process.env.BASE_URL,
    storageState: 'auth.json' // Reuse authentication
  }
});
```

## Advanced Customization Features

### 1. Dynamic Configuration Loading
```typescript
// config-loader.ts
export function loadConfig(environment: string, team: string) {
  const baseConfig = require('./playwright.config.base');
  const envConfig = require(`./configs/${environment}.config`);
  const teamConfig = require(`./configs/${team}.config`);
  
  return mergeConfigs(baseConfig, envConfig, teamConfig);
}
```

### 2. Custom Reporters
```typescript
// custom-reporter.ts
class CompanyReporter implements Reporter {
  onTestEnd(test: TestCase, result: TestResult) {
    // Send results to company dashboard
    this.sendToCompanyDashboard(test, result);
  }
  
  onEnd(result: FullResult) {
    // Generate company-specific reports
    this.generateCompanyReport(result);
  }
}
```

### 3. Plugin System
```typescript
// plugins/security-plugin.ts
export function securityPlugin() {
  return {
    name: 'security-checks',
    setup(config) {
      // Add security-specific test configurations
      config.use.extraHTTPHeaders = {
        ...config.use.extraHTTPHeaders,
        'X-Security-Test': 'enabled'
      };
    }
  };
}
```

This comprehensive Jenkins configuration and customization guide provides a solid foundation for implementing Playwright testing in various CI/CD environments while maintaining company standards and allowing for team-specific customizations.