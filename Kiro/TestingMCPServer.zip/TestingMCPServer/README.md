# Testing MCP Server

A Model Context Protocol (MCP) server that generates comprehensive Playwright functional tests for React.js applications. This server helps development teams quickly scaffold and maintain end-to-end test suites with consistent structure and best practices.

## Features

- 🏗️ **Automated Test Structure Setup** - Creates organized test directories (`tests/functional/e2e`)
- ⚙️ **Playwright Configuration Generation** - Tailored configs for React.js applications
- 🧪 **Smart Test Case Generation** - Supports multiple test types (page, component, form, navigation, API)
- 📝 **Page Object Model** - Generates maintainable page objects automatically
- 🚀 **Script Generation** - Creates npm scripts and CI/CD workflows
- 📱 **Mobile Testing** - Includes mobile device testing configurations
- 🔧 **Team Sharing** - Designed for easy sharing across development teams

## Installation

### For Team Distribution

1. **Clone and build the server:**
```bash
git clone <repository-url>
cd testing-mcp-server
npm install
npm run build
```

2. **Install globally for team use:**
```bash
npm install -g .
```

3. **Configure in your MCP client:**
```json
{
  "mcpServers": {
    "testing-server": {
      "command": "testing-mcp-server",
      "disabled": false,
      "autoApprove": [
        "setup_test_structure",
        "generate_playwright_config",
        "generate_test_case",
        "generate_test_script"
      ]
    }
  }
}
```

### For Development

```bash
npm install
npm run dev  # Watch mode for development
```

## Available Tools

### 1. `setup_test_structure`
Creates the complete test folder structure and utility files.

**Parameters:**
- `projectPath` (required): Path to your React.js project root

**Creates:**
- `tests/functional/e2e/` directory structure
- Base page object model
- Test utilities and fixtures
- Screenshot directory

### 2. `generate_playwright_config`
Generates a comprehensive Playwright configuration file.

**Parameters:**
- `projectPath` (required): Path to your React.js project root
- `baseUrl` (optional): Application base URL (default: http://localhost:3000)
- `browsers` (optional): Array of browsers to test (default: ["chromium", "firefox", "webkit"])

**Features:**
- Multi-browser testing
- Mobile device configurations
- Automatic dev server startup
- HTML, JSON, and JUnit reporters
- Screenshot and video on failure

### 3. `generate_test_case`
Generates functional test cases based on component type and scenarios.

**Parameters:**
- `projectPath` (required): Path to your React.js project root
- `testName` (required): Name of the test case
- `componentName` (required): Name of the React component to test
- `testType` (required): Type of test - "page", "component", "form", "navigation", or "api"
- `testScenarios` (optional): Array of specific test scenarios

**Test Types:**
- **Page**: Full page testing with navigation and content verification
- **Component**: Individual component testing with interactions
- **Form**: Form validation, submission, and error handling
- **Navigation**: Menu navigation and routing tests
- **API**: API integration and error handling tests

### 4. `generate_test_script`
Creates npm scripts, CI/CD workflows, and development tools.

**Parameters:**
- `projectPath` (required): Path to your React.js project root

**Generates:**
- npm scripts for various test scenarios
- GitHub Actions workflow
- VS Code configuration
- Convenient test runner script

## Usage Examples

### Basic Setup
```javascript
// 1. Setup test structure
await mcp.callTool('setup_test_structure', {
  projectPath: '/path/to/my-react-app'
});

// 2. Generate Playwright config
await mcp.callTool('generate_playwright_config', {
  projectPath: '/path/to/my-react-app',
  baseUrl: 'http://localhost:3000',
  browsers: ['chromium', 'firefox']
});

// 3. Generate test scripts
await mcp.callTool('generate_test_script', {
  projectPath: '/path/to/my-react-app'
});
```

### Generate Different Test Types

```javascript
// Login form test
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/my-react-app',
  testName: 'User Login Flow',
  componentName: 'LoginForm',
  testType: 'form',
  testScenarios: [
    'should login with valid credentials',
    'should show error for invalid credentials',
    'should handle password reset'
  ]
});

// Navigation test
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/my-react-app',
  testName: 'Main Navigation',
  componentName: 'Header',
  testType: 'navigation',
  testScenarios: [
    'should navigate to all main pages',
    'should highlight active menu item',
    'should work on mobile devices'
  ]
});

// API integration test
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/my-react-app',
  testName: 'Product List API',
  componentName: 'ProductList',
  testType: 'api',
  testScenarios: [
    'should load products successfully',
    'should handle API errors',
    'should show loading states'
  ]
});
```

## Generated Test Structure

```
your-react-app/
├── tests/
│   └── functional/
│       └── e2e/
│           ├── fixtures/
│           │   └── test-data.ts
│           ├── pages/
│           │   ├── base-page.ts
│           │   └── component-page.ts
│           ├── utils/
│           │   └── test-utils.ts
│           ├── screenshots/
│           └── *.spec.ts
├── playwright.config.ts
├── test-runner.js
└── .github/
    └── workflows/
        └── playwright.yml
```

## Team Sharing

### Option 1: NPM Package
1. Publish to your private npm registry:
```bash
npm publish --registry=https://your-private-registry.com
```

2. Team members install:
```bash
npm install -g @yourorg/testing-mcp-server
```

### Option 2: Git Repository
1. Share the repository URL
2. Team members clone and install:
```bash
git clone <repo-url>
cd testing-mcp-server
npm install -g .
```

### Option 3: Docker Container
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN npm install && npm run build
CMD ["node", "dist/index.js"]
```

## Best Practices

### Test Organization
- Use descriptive test names that explain the behavior being tested
- Group related tests using `test.describe()`
- Keep test data in fixtures for reusability
- Use page objects for maintainable selectors

### Data Test IDs
Add `data-testid` attributes to your React components:
```jsx
<button data-testid="login-button">Login</button>
<form data-testid="login-form">...</form>
<div data-testid="error-message">...</div>
```

### CI/CD Integration
The generated GitHub Actions workflow includes:
- Automatic browser installation
- Parallel test execution
- Artifact collection for reports
- Test result reporting

## Troubleshooting

### Common Issues

1. **Tests fail to find elements**
   - Ensure your React app uses `data-testid` attributes
   - Check that the base URL is correct
   - Verify the app is fully loaded before tests run

2. **Slow test execution**
   - Use `test.describe.configure({ mode: 'parallel' })` for independent tests
   - Optimize selectors to be more specific
   - Consider using `page.waitForLoadState('networkidle')`

3. **Flaky tests**
   - Add proper wait conditions
   - Use `expect.poll()` for dynamic content
   - Implement retry logic for network-dependent tests

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
- Create an issue in the repository
- Check the Playwright documentation: https://playwright.dev
- Review MCP documentation: https://modelcontextprotocol.io