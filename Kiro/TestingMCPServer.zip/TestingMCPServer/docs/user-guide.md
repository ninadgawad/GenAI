# Testing MCP Server - User Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Installation](#installation)
3. [Quick Start](#quick-start)
4. [Tools Reference](#tools-reference)
5. [Resources Reference](#resources-reference)
6. [Prompts Reference](#prompts-reference)
7. [Workflows](#workflows)
8. [Best Practices](#best-practices)
9. [Troubleshooting](#troubleshooting)
10. [Advanced Usage](#advanced-usage)

## Introduction

The Testing MCP Server is a powerful tool that automates the creation and configuration of Playwright functional tests for React.js applications. It helps development teams:

- **Standardize Testing**: Enforce consistent testing patterns across projects
- **Accelerate Development**: Generate test scaffolding in seconds
- **Ensure Quality**: Follow company standards and best practices
- **Simplify CI/CD**: Create platform-specific configurations automatically
- **Improve Collaboration**: Share testing standards across teams

### Who Should Use This Guide

- **Frontend Developers**: Creating tests for React components and pages
- **QA Engineers**: Setting up comprehensive test suites
- **DevOps Engineers**: Configuring CI/CD pipelines for testing
- **Team Leads**: Establishing testing standards and workflows

## Installation

### Prerequisites

- Node.js 18.x or higher
- npm or yarn package manager
- MCP-compatible client (e.g., Kiro IDE, Claude Desktop)

### Step 1: Install the Server

#### Option A: Global Installation
```bash
# Clone the repository
git clone <repository-url>
cd testing-mcp-server

# Install dependencies and build
npm install
npm run build

# Install globally
npm install -g .
```

#### Option B: Local Installation
```bash
# In your project directory
npm install testing-mcp-server
```

### Step 2: Configure MCP Client

Add the server to your MCP client configuration:

```json
{
  "mcpServers": {
    "testing-server": {
      "command": "testing-mcp-server",
      "disabled": false,
      "autoApprove": [
        "setup_test_structure",
        "generate_playwright_config",
        "generate_test_case",
        "generate_test_script",
        "generate_cicd_config"
      ]
    }
  }
}
```

### Step 3: Verify Installation

Test the server connection:
```bash
# Check if server is accessible
testing-mcp-server --version
```

## Quick Start

### 1. Initialize Test Structure

Start by setting up the basic test structure for your React project:

```javascript
// Call the setup tool
await mcp.callTool('setup_test_structure', {
  projectPath: '/path/to/your/react-app'
});
```

**What this creates:**
```
your-react-app/
├── tests/
│   └── functional/
│       └── e2e/
│           ├── fixtures/test-data.ts
│           ├── pages/base-page.ts
│           ├── utils/test-utils.ts
│           └── screenshots/
```

### 2. Generate Playwright Configuration

Create a Playwright configuration tailored for your React app:

```javascript
await mcp.callTool('generate_playwright_config', {
  projectPath: '/path/to/your/react-app',
  baseUrl: 'http://localhost:3000',
  browsers: ['chromium', 'firefox', 'webkit']
});
```

### 3. Create Your First Test

Generate a test case for a specific component:

```javascript
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/your/react-app',
  testName: 'User Login Flow',
  componentName: 'LoginForm',
  testType: 'form',
  testScenarios: [
    'should login with valid credentials',
    'should show error for invalid credentials',
    'should handle password reset'
  ]
});
```

### 4. Set Up Test Scripts

Generate npm scripts and development tools:

```javascript
await mcp.callTool('generate_test_script', {
  projectPath: '/path/to/your/react-app'
});
```

### 5. Run Your Tests

```bash
# Install Playwright browsers
npm run test:e2e:install

# Run tests in headless mode
npm run test:e2e

# Run tests with visible browser
npm run test:e2e:headed

# Debug tests
npm run test:e2e:debug
```
##
 Tools Reference

### setup_test_structure

**Purpose**: Creates the foundational test directory structure and utility files.

**Parameters**:
- `projectPath` (string, required): Path to your React.js project root

**Example**:
```javascript
await mcp.callTool('setup_test_structure', {
  projectPath: '/Users/developer/my-react-app'
});
```

**Generated Files**:
- `tests/functional/e2e/utils/test-utils.ts` - Common test utilities
- `tests/functional/e2e/pages/base-page.ts` - Base page object class
- `tests/functional/e2e/fixtures/test-data.ts` - Test data fixtures
- Directory structure for organized testing

**When to Use**:
- Starting a new project
- Adding E2E testing to existing project
- Standardizing test structure across projects

---

### generate_playwright_config

**Purpose**: Generates a comprehensive Playwright configuration file optimized for React applications.

**Parameters**:
- `projectPath` (string, required): Path to your React.js project root
- `baseUrl` (string, optional): Application base URL (default: http://localhost:3000)
- `browsers` (array, optional): Browsers to test (default: ['chromium', 'firefox', 'webkit'])

**Example**:
```javascript
await mcp.callTool('generate_playwright_config', {
  projectPath: '/Users/developer/my-react-app',
  baseUrl: 'http://localhost:3001',
  browsers: ['chromium', 'firefox']
});
```

**Generated Files**:
- `playwright.config.ts` - Main configuration file
- Updated `.gitignore` with Playwright entries

**Configuration Features**:
- Multi-browser testing setup
- Mobile device configurations
- Automatic dev server startup
- HTML, JSON, and JUnit reporters
- Screenshot and video capture on failure
- Trace collection on retry

**When to Use**:
- Initial project setup
- Updating browser support
- Changing test configuration
- Adding new environments

---

### generate_test_case

**Purpose**: Creates specific test cases with corresponding page object models.

**Parameters**:
- `projectPath` (string, required): Path to your React.js project root
- `testName` (string, required): Descriptive name for the test case
- `componentName` (string, required): Name of the React component being tested
- `testType` (enum, required): Type of test - 'page', 'component', 'form', 'navigation', 'api'
- `testScenarios` (array, optional): Custom test scenarios to include

**Test Types Explained**:

#### Page Tests
For testing complete pages and their functionality.

```javascript
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/project',
  testName: 'Home Page Functionality',
  componentName: 'HomePage',
  testType: 'page',
  testScenarios: [
    'should load the page successfully',
    'should display main navigation',
    'should be responsive on mobile'
  ]
});
```

#### Component Tests
For testing individual React components.

```javascript
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/project',
  testName: 'Product Card Component',
  componentName: 'ProductCard',
  testType: 'component',
  testScenarios: [
    'should display product information',
    'should handle add to cart action',
    'should show loading state'
  ]
});
```

#### Form Tests
For testing form validation and submission.

```javascript
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/project',
  testName: 'Registration Form',
  componentName: 'RegistrationForm',
  testType: 'form',
  testScenarios: [
    'should submit with valid data',
    'should show validation errors',
    'should handle server errors'
  ]
});
```

#### Navigation Tests
For testing menus and routing.

```javascript
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/project',
  testName: 'Main Navigation',
  componentName: 'MainNav',
  testType: 'navigation',
  testScenarios: [
    'should navigate between pages',
    'should highlight active page',
    'should work on mobile'
  ]
});
```

#### API Tests
For testing API integrations and error handling.

```javascript
await mcp.callTool('generate_test_case', {
  projectPath: '/path/to/project',
  testName: 'User API Integration',
  componentName: 'UserProfile',
  testType: 'api',
  testScenarios: [
    'should load user data',
    'should handle API errors',
    'should show loading states'
  ]
});
```

**Generated Files**:
- `{testName}.spec.ts` - Test specification file
- `{componentName}-page.ts` - Page object model

**When to Use**:
- Adding tests for new features
- Testing specific components
- Creating regression tests
- Standardizing test patterns---


### generate_test_script

**Purpose**: Creates npm scripts, development tools, and CI/CD workflows.

**Parameters**:
- `projectPath` (string, required): Path to your React.js project root

**Example**:
```javascript
await mcp.callTool('generate_test_script', {
  projectPath: '/Users/developer/my-react-app'
});
```

**Generated Files**:
- Updated `package.json` with test scripts
- `test-runner.js` - Custom test runner with convenience commands
- `.github/workflows/playwright.yml` - GitHub Actions workflow
- `.vscode/settings.json` - VS Code configuration for better development experience

**Generated npm Scripts**:
```json
{
  "test:e2e": "playwright test",
  "test:e2e:headed": "playwright test --headed",
  "test:e2e:debug": "playwright test --debug",
  "test:e2e:ui": "playwright test --ui",
  "test:e2e:report": "playwright show-report",
  "test:e2e:install": "playwright install",
  "test:e2e:codegen": "playwright codegen localhost:3000",
  "test:e2e:mobile": "playwright test --project=\"Mobile Chrome\"",
  "test:e2e:ci": "playwright test --reporter=github"
}
```

**Custom Test Runner Commands**:
```bash
# Run all tests
node test-runner.js run

# Run with visible browser
node test-runner.js headed

# Debug specific test
node test-runner.js debug login.spec.ts

# Generate new tests
node test-runner.js codegen

# Run only Chrome tests
node test-runner.js chrome
```

**When to Use**:
- Initial project setup
- Adding CI/CD integration
- Updating development workflows
- Standardizing team scripts

---

### generate_cicd_config

**Purpose**: Generates CI/CD configuration files for various platforms with company standards.

**Parameters**:
- `projectPath` (string, required): Path to your React.js project root
- `cicdPlatform` (enum, required): Platform - 'jenkins', 'gitlab', 'azure-devops', 'github-actions', 'circleci', 'travis'
- `companyStandardsPath` (string, optional): Path to company standards file
- `customConfig` (object, optional): Custom configuration overrides

**Custom Configuration Options**:
```javascript
{
  nodeVersion: '20',           // Node.js version
  testTimeout: 45,            // Test timeout in minutes
  parallelJobs: 6,            // Number of parallel workers
  browsers: ['chromium', 'firefox', 'webkit'],
  notifications: {
    slack: { channel: '#ci-cd' },
    email: { recipients: 'team@company.com' }
  },
  deploymentStages: ['dev', 'staging', 'production']
}
```

**Platform Examples**:

#### Jenkins
```javascript
await mcp.callTool('generate_cicd_config', {
  projectPath: '/path/to/project',
  cicdPlatform: 'jenkins',
  customConfig: {
    nodeVersion: '18',
    parallelJobs: 4,
    notifications: {
      slack: { channel: '#frontend-ci' }
    }
  }
});
```

#### GitLab CI
```javascript
await mcp.callTool('generate_cicd_config', {
  projectPath: '/path/to/project',
  cicdPlatform: 'gitlab',
  customConfig: {
    browsers: ['chromium', 'firefox'],
    deploymentStages: ['staging', 'production']
  }
});
```

#### GitHub Actions
```javascript
await mcp.callTool('generate_cicd_config', {
  projectPath: '/path/to/project',
  cicdPlatform: 'github-actions',
  customConfig: {
    nodeVersion: '20',
    testTimeout: 30
  }
});
```

**Generated Files by Platform**:
- **Jenkins**: `Jenkinsfile`
- **GitLab**: `.gitlab-ci.yml`
- **Azure DevOps**: `azure-pipelines.yml`
- **GitHub Actions**: `.github/workflows/playwright.yml`
- **CircleCI**: `.circleci/config.yml`
- **Travis CI**: `.travis.yml`

**When to Use**:
- Setting up CI/CD for new projects
- Migrating between CI/CD platforms
- Updating pipeline configurations
- Standardizing deployment processes

## Resources Reference

### Company Testing Standards

**URI**: `company-standards://testing-standards`

Access comprehensive testing guidelines and standards:

```javascript
const standards = await mcp.readResource('company-standards://testing-standards');
```

**Content Includes**:
- Test structure and organization guidelines
- Naming conventions
- Code quality standards
- Security requirements
- Browser and device coverage
- Performance standards
- Maintenance procedures

### CI/CD Templates

**URI**: `company-standards://cicd-templates`

Access pre-configured CI/CD templates:

```javascript
const templates = await mcp.readResource('company-standards://cicd-templates');
```

**Content Includes**:
- Platform-specific configuration templates
- Environment variable setups
- Deployment stage configurations
- Notification settings
- Security scanning integrations

### Test Patterns

**URI**: `company-standards://test-patterns`

Access approved test patterns and code snippets:

```javascript
const patterns = await mcp.readResource('company-standards://test-patterns');
```

**Content Includes**:
- Page Object Model patterns
- Test data management patterns
- API mocking patterns
- Accessibility testing patterns
- Performance testing patterns## 
Prompts Reference

### generate_test_with_standards

**Purpose**: Generate comprehensive test suites following company standards.

**Arguments**:
- `component_name` (required): Name of the React component
- `test_type` (required): Type of test (page, component, form, navigation, api)
- `company_standards` (optional): Specific standards to follow

**Example**:
```javascript
const prompt = await mcp.getPrompt('generate_test_with_standards', {
  component_name: 'ShoppingCart',
  test_type: 'component',
  company_standards: 'Follow accessibility and performance guidelines'
});
```

### setup_cicd_pipeline

**Purpose**: Setup complete CI/CD pipeline with company standards.

**Arguments**:
- `platform` (required): CI/CD platform
- `project_type` (required): Type of project (react, node, fullstack)

**Example**:
```javascript
const prompt = await mcp.getPrompt('setup_cicd_pipeline', {
  platform: 'jenkins',
  project_type: 'react'
});
```

## Workflows

### Workflow 1: New Project Setup

**Scenario**: Setting up testing for a new React project

**Steps**:
1. **Initialize Structure**
   ```javascript
   await mcp.callTool('setup_test_structure', {
     projectPath: '/path/to/new-project'
   });
   ```

2. **Configure Playwright**
   ```javascript
   await mcp.callTool('generate_playwright_config', {
     projectPath: '/path/to/new-project',
     baseUrl: 'http://localhost:3000'
   });
   ```

3. **Set Up Scripts**
   ```javascript
   await mcp.callTool('generate_test_script', {
     projectPath: '/path/to/new-project'
   });
   ```

4. **Configure CI/CD**
   ```javascript
   await mcp.callTool('generate_cicd_config', {
     projectPath: '/path/to/new-project',
     cicdPlatform: 'github-actions'
   });
   ```

5. **Install Dependencies**
   ```bash
   cd /path/to/new-project
   npm install
   npm run test:e2e:install
   ```

### Workflow 2: Adding Tests for New Feature

**Scenario**: Adding tests for a new login component

**Steps**:
1. **Generate Login Form Tests**
   ```javascript
   await mcp.callTool('generate_test_case', {
     projectPath: '/path/to/project',
     testName: 'User Authentication',
     componentName: 'LoginForm',
     testType: 'form',
     testScenarios: [
       'should authenticate valid user',
       'should reject invalid credentials',
       'should handle forgot password',
       'should validate required fields'
     ]
   });
   ```

2. **Generate Navigation Tests**
   ```javascript
   await mcp.callTool('generate_test_case', {
     projectPath: '/path/to/project',
     testName: 'Authentication Navigation',
     componentName: 'AuthNav',
     testType: 'navigation',
     testScenarios: [
       'should redirect after login',
       'should show user menu when authenticated',
       'should handle logout'
     ]
   });
   ```

3. **Run Tests**
   ```bash
   npm run test:e2e:headed -- user-authentication.spec.ts
   ```

### Workflow 3: Multi-Environment Setup

**Scenario**: Setting up tests for development, staging, and production

**Steps**:
1. **Create Environment Configs**
   ```javascript
   // Development
   await mcp.callTool('generate_playwright_config', {
     projectPath: '/path/to/project',
     baseUrl: 'http://localhost:3000',
     browsers: ['chromium']
   });
   ```

2. **Generate CI/CD for Multiple Environments**
   ```javascript
   await mcp.callTool('generate_cicd_config', {
     projectPath: '/path/to/project',
     cicdPlatform: 'gitlab',
     customConfig: {
       deploymentStages: ['dev', 'staging', 'production'],
       notifications: {
         slack: { channel: '#deployments' }
       }
     }
   });
   ```

3. **Create Environment-Specific Tests**
   ```javascript
   // Smoke tests for production
   await mcp.callTool('generate_test_case', {
     projectPath: '/path/to/project',
     testName: 'Production Smoke Tests',
     componentName: 'App',
     testType: 'page',
     testScenarios: [
       'should load homepage',
       'should handle basic navigation',
       'should display critical content'
     ]
   });
   ```

## Best Practices

### Test Organization

#### 1. Use Descriptive Test Names
```javascript
// ✅ Good
'should display error message when login fails with invalid credentials'

// ❌ Bad
'test login error'
```

#### 2. Follow the AAA Pattern
```typescript
test('should add item to cart', async ({ page }) => {
  // Arrange
  const productPage = new ProductPage(page);
  await productPage.goto('/product/123');
  
  // Act
  await productPage.clickAddToCart();
  
  // Assert
  await expect(page.locator('[data-testid="cart-count"]')).toHaveText('1');
});
```

#### 3. Use Page Object Models
```typescript
// ✅ Good - Using page objects
const loginPage = new LoginPage(page);
await loginPage.login('user@example.com', 'password');

// ❌ Bad - Direct element interaction
await page.fill('[data-testid="email"]', 'user@example.com');
await page.fill('[data-testid="password"]', 'password');
await page.click('[data-testid="submit"]');
```

### Data Management

#### 1. Use Test Fixtures
```typescript
import { testData } from '../fixtures/test-data';

test('should login with valid user', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.login(testData.users.validUser.email, testData.users.validUser.password);
});
```

#### 2. Generate Dynamic Test Data
```typescript
const testUser = {
  email: `test${Date.now()}@example.com`,
  username: `user${Date.now()}`,
  password: 'TestPassword123!'
};
```

### Performance Optimization

#### 1. Use Efficient Selectors
```typescript
// ✅ Good - Data test IDs
await page.locator('[data-testid="submit-button"]').click();

// ❌ Bad - Complex CSS selectors
await page.locator('div > form > div:nth-child(3) > button').click();
```

#### 2. Optimize Wait Strategies
```typescript
// ✅ Good - Wait for specific condition
await page.waitForSelector('[data-testid="content-loaded"]');

// ❌ Bad - Arbitrary delays
await page.waitForTimeout(5000);
```#
# Troubleshooting

### Common Issues

#### 1. Tests Fail to Find Elements

**Problem**: `Error: Locator '[data-testid="button"]' not found`

**Solutions**:
- Ensure your React components have `data-testid` attributes
- Check that the application is fully loaded before interacting
- Use `page.waitForSelector()` for dynamic content

```typescript
// Add to your React components
<button data-testid="submit-button">Submit</button>

// Wait for element in tests
await page.waitForSelector('[data-testid="submit-button"]');
```

#### 2. Flaky Tests

**Problem**: Tests pass sometimes but fail randomly

**Solutions**:
- Use proper wait conditions instead of timeouts
- Handle race conditions with `expect.poll()`
- Implement retry logic for network-dependent operations

```typescript
// ✅ Good - Polling for dynamic content
await expect.poll(async () => {
  return await page.locator('[data-testid="status"]').textContent();
}).toBe('Ready');

// ❌ Bad - Fixed timeout
await page.waitForTimeout(2000);
```

#### 3. Slow Test Execution

**Problem**: Tests take too long to run

**Solutions**:
- Use parallel execution with `--workers` flag
- Optimize selectors for better performance
- Mock external API calls
- Use `page.waitForLoadState('networkidle')` appropriately

```bash
# Run tests in parallel
npm run test:e2e -- --workers=4

# Run specific test file
npm run test:e2e -- login.spec.ts
```

#### 4. CI/CD Pipeline Failures

**Problem**: Tests pass locally but fail in CI

**Solutions**:
- Ensure consistent environment variables
- Use headless mode in CI
- Increase timeouts for slower CI environments
- Check browser installation in CI

```yaml
# GitHub Actions example
- name: Install Playwright browsers
  run: npx playwright install --with-deps

- name: Run tests
  run: npm run test:e2e:ci
  env:
    CI: true
```

### Debugging Techniques

#### 1. Use Debug Mode
```bash
# Run tests in debug mode
npm run test:e2e:debug

# Debug specific test
npm run test:e2e:debug -- --grep "login"
```

#### 2. Enable Trace Viewer
```bash
# Run with trace collection
npm run test:e2e:trace

# View traces
npx playwright show-trace trace.zip
```

#### 3. Take Screenshots
```typescript
test('debug failing test', async ({ page }) => {
  await page.goto('/');
  
  // Take screenshot for debugging
  await page.screenshot({ path: 'debug-screenshot.png' });
  
  // Continue with test...
});
```

### Getting Help

#### 1. Check Logs
- Review test output for specific error messages
- Check browser console logs in headed mode
- Examine network requests in debug mode

#### 2. Community Resources
- [Playwright Documentation](https://playwright.dev)
- [MCP Documentation](https://modelcontextprotocol.io)
- Stack Overflow with `playwright` tag

#### 3. Internal Support
- Check company testing standards documentation
- Contact your QA team or testing champions
- Review team-specific testing guidelines

## Advanced Usage

### Custom Test Patterns

#### 1. Data-Driven Testing
```typescript
const loginScenarios = [
  { email: '', password: 'valid', expectedError: 'Email is required' },
  { email: 'invalid', password: '', expectedError: 'Password is required' },
  { email: 'test@example.com', password: 'short', expectedError: 'Password too short' }
];

loginScenarios.forEach(scenario => {
  test(`should validate ${scenario.expectedError}`, async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.login(scenario.email, scenario.password);
    await expect(page.locator('[data-testid="error"]')).toHaveText(scenario.expectedError);
  });
});
```

#### 2. Custom Fixtures
```typescript
// fixtures/auth.ts
import { test as base } from '@playwright/test';

export const test = base.extend({
  authenticatedPage: async ({ page }, use) => {
    // Login before each test
    await page.goto('/login');
    await page.fill('[data-testid="email"]', 'user@example.com');
    await page.fill('[data-testid="password"]', 'password');
    await page.click('[data-testid="submit"]');
    await page.waitForURL('/dashboard');
    
    await use(page);
  }
});

// Usage in tests
test('should access protected page', async ({ authenticatedPage }) => {
  await authenticatedPage.goto('/protected');
  await expect(authenticatedPage).toHaveURL('/protected');
});
```

#### 3. Custom Matchers
```typescript
// matchers/custom-matchers.ts
import { expect } from '@playwright/test';

expect.extend({
  async toBeAccessible(locator) {
    // Custom accessibility check
    const element = await locator.elementHandle();
    const hasAriaLabel = await element?.getAttribute('aria-label');
    const hasRole = await element?.getAttribute('role');
    
    return {
      pass: !!(hasAriaLabel || hasRole),
      message: () => 'Element should have accessibility attributes'
    };
  }
});

// Usage
await expect(page.locator('[data-testid="button"]')).toBeAccessible();
```

### Integration with Company Tools

#### 1. Custom Reporting
```typescript
// reporters/company-reporter.ts
class CompanyReporter {
  onTestEnd(test, result) {
    // Send results to company dashboard
    this.sendToCompanyDashboard({
      testName: test.title,
      status: result.status,
      duration: result.duration,
      project: process.env.PROJECT_NAME
    });
  }
  
  async sendToCompanyDashboard(data) {
    // Implementation for company-specific reporting
    await fetch('https://company-dashboard.com/api/test-results', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  }
}
```

#### 2. Environment-Specific Configuration
```typescript
// config/environments.ts
export const environments = {
  development: {
    baseURL: 'http://localhost:3000',
    timeout: 10000,
    retries: 0
  },
  staging: {
    baseURL: 'https://staging.company.com',
    timeout: 30000,
    retries: 2
  },
  production: {
    baseURL: 'https://app.company.com',
    timeout: 30000,
    retries: 3
  }
};

// Usage in playwright.config.ts
const env = process.env.TEST_ENV || 'development';
const config = environments[env];

export default defineConfig({
  ...config,
  // other configuration
});
```

### Performance Testing Integration

#### 1. Lighthouse Integration
```typescript
import { playAudit } from 'playwright-lighthouse';

test('should meet performance standards', async ({ page }) => {
  await page.goto('/');
  
  const audit = await playAudit({
    page,
    thresholds: {
      performance: 90,
      accessibility: 95,
      'best-practices': 90,
      seo: 85
    }
  });
  
  expect(audit.lhr.categories.performance.score * 100).toBeGreaterThan(90);
});
```

#### 2. Custom Performance Metrics
```typescript
test('should load within performance budget', async ({ page }) => {
  const startTime = Date.now();
  
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  
  const loadTime = Date.now() - startTime;
  const performanceTiming = await page.evaluate(() => {
    return JSON.stringify(performance.timing);
  });
  
  console.log('Performance metrics:', performanceTiming);
  expect(loadTime).toBeLessThan(3000); // 3 second budget
});
```

This comprehensive user guide provides everything needed to effectively use the Testing MCP Server, from basic setup to advanced customization patterns. Teams can reference specific sections based on their needs and experience level.