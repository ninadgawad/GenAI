import * as fs from 'fs-extra';
import * as path from 'path';

export async function loadCompanyStandards(type: string): Promise<string> {
  const standardsDir = path.join(process.cwd(), 'company-standards');
  
  switch (type) {
    case 'testing-standards':
      return await loadTestingStandards(standardsDir);
    case 'cicd-templates':
      return await loadCicdTemplates(standardsDir);
    case 'test-patterns':
      return await loadTestPatterns(standardsDir);
    default:
      throw new Error(`Unknown standards type: ${type}`);
  }
}

async function loadTestingStandards(standardsDir: string): Promise<string> {
  const filePath = path.join(standardsDir, 'testing-standards.md');
  
  if (await fs.pathExists(filePath)) {
    return await fs.readFile(filePath, 'utf8');
  }
  
  // Return default standards if file doesn't exist
  return getDefaultTestingStandards();
}

async function loadCicdTemplates(standardsDir: string): Promise<string> {
  const filePath = path.join(standardsDir, 'cicd-templates.json');
  
  if (await fs.pathExists(filePath)) {
    return await fs.readFile(filePath, 'utf8');
  }
  
  // Return default templates if file doesn't exist
  return JSON.stringify(getDefaultCicdTemplates(), null, 2);
}

async function loadTestPatterns(standardsDir: string): Promise<string> {
  const filePath = path.join(standardsDir, 'test-patterns.txt');
  
  if (await fs.pathExists(filePath)) {
    return await fs.readFile(filePath, 'utf8');
  }
  
  // Return default patterns if file doesn't exist
  return getDefaultTestPatterns();
}

function getDefaultTestingStandards(): string {
  return `# Company Testing Standards

## Test Structure and Organization

### Directory Structure
- All E2E tests must be placed in \`tests/functional/e2e/\`
- Page objects must be in \`tests/functional/e2e/pages/\`
- Test utilities must be in \`tests/functional/e2e/utils/\`
- Test fixtures must be in \`tests/functional/e2e/fixtures/\`

### Naming Conventions
- Test files: \`*.spec.ts\` or \`*.test.ts\`
- Page objects: \`*-page.ts\`
- Test utilities: \`*-utils.ts\`
- Test data: \`*-data.ts\`

## Code Quality Standards

### Test Writing Guidelines
1. **Descriptive Test Names**: Use clear, descriptive test names that explain the expected behavior
2. **AAA Pattern**: Arrange, Act, Assert structure for all tests
3. **Single Responsibility**: Each test should verify one specific behavior
4. **Data-Driven Tests**: Use test fixtures for reusable test data
5. **Page Object Model**: Always use page objects for element interactions

### Required Test Categories
1. **Happy Path Tests**: Core functionality working as expected
2. **Error Handling**: How the application handles errors and edge cases
3. **Accessibility Tests**: WCAG compliance and keyboard navigation
4. **Mobile Responsiveness**: Tests on mobile viewports
5. **Performance Tests**: Load times and interaction responsiveness

### Security Requirements
- Never hardcode sensitive data in tests
- Use environment variables for credentials
- Implement proper test data cleanup
- Follow OWASP testing guidelines

## Browser and Device Coverage

### Required Browsers
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

### Required Mobile Devices
- iPhone 12/13/14
- Samsung Galaxy S21/S22
- iPad (latest)

## Reporting and Documentation

### Test Reports
- HTML reports for local development
- JUnit XML for CI/CD integration
- JSON reports for custom processing
- Screenshots on failure
- Video recordings for failed tests

### Documentation Requirements
- Each test suite must have a README
- Page objects must be documented
- Complex test scenarios must have inline comments
- Test data must be documented

## CI/CD Integration

### Pipeline Requirements
- Tests must run on every pull request
- Tests must pass before merge
- Parallel execution for faster feedback
- Automatic retry for flaky tests (max 2 retries)

### Environment Management
- Separate test environments for different branches
- Database seeding and cleanup
- Service mocking for external dependencies
- Environment-specific configuration

## Performance Standards

### Test Execution Time
- Individual tests: < 30 seconds
- Full test suite: < 15 minutes
- Parallel execution: 4+ workers
- Timeout handling: Proper timeouts for all operations

### Resource Usage
- Memory usage monitoring
- CPU usage optimization
- Network request optimization
- Cleanup after test completion

## Maintenance and Updates

### Regular Maintenance
- Monthly review of flaky tests
- Quarterly browser compatibility updates
- Annual testing strategy review
- Continuous test data updates

### Version Control
- All test code must be version controlled
- Proper commit messages for test changes
- Code review required for test modifications
- Branching strategy aligned with development workflow`;
}

function getDefaultCicdTemplates(): any {
  return {
    jenkins: {
      pipeline: {
        agent: "any",
        environment: {
          NODE_VERSION: "18",
          PLAYWRIGHT_BROWSERS_PATH: "$WORKSPACE/browsers"
        },
        stages: [
          {
            name: "Checkout",
            steps: ["checkout scm"]
          },
          {
            name: "Install Dependencies",
            steps: [
              "nvm use $NODE_VERSION",
              "npm ci",
              "npx playwright install --with-deps"
            ]
          },
          {
            name: "Lint and Type Check",
            steps: [
              "npm run lint",
              "npm run type-check"
            ]
          },
          {
            name: "Unit Tests",
            steps: ["npm run test:unit"]
          },
          {
            name: "Build Application",
            steps: ["npm run build"]
          },
          {
            name: "E2E Tests",
            steps: [
              "npm start &",
              "sleep 30",
              "npm run test:e2e:ci"
            ],
            post: [
              "publishHTML([allowMissing: false, alwaysLinkToLastBuild: true, keepAll: true, reportDir: 'playwright-report', reportFiles: 'index.html', reportName: 'Playwright Report'])",
              "archiveArtifacts artifacts: 'test-results/**/*', allowEmptyArchive: true"
            ]
          }
        ]
      }
    },
    gitlab: {
      stages: ["install", "lint", "test", "build", "deploy"],
      variables: {
        NODE_VERSION: "18",
        PLAYWRIGHT_BROWSERS_PATH: "$CI_PROJECT_DIR/browsers"
      },
      cache: {
        paths: ["node_modules/", "browsers/"]
      },
      jobs: {
        install: {
          stage: "install",
          script: [
            "npm ci",
            "npx playwright install --with-deps"
          ]
        },
        lint: {
          stage: "lint",
          script: ["npm run lint", "npm run type-check"]
        },
        "e2e-tests": {
          stage: "test",
          script: [
            "npm run build",
            "npm start &",
            "sleep 30",
            "npm run test:e2e:ci"
          ],
          artifacts: {
            when: "always",
            paths: ["playwright-report/", "test-results/"],
            reports: {
              junit: "test-results/junit.xml"
            }
          }
        }
      }
    },
    "azure-devops": {
      trigger: ["main", "develop"],
      pool: {
        vmImage: "ubuntu-latest"
      },
      variables: {
        nodeVersion: "18.x"
      },
      stages: [
        {
          stage: "Test",
          jobs: [
            {
              job: "E2ETests",
              steps: [
                {
                  task: "NodeTool@0",
                  inputs: {
                    versionSpec: "$(nodeVersion)"
                  }
                },
                {
                  script: "npm ci",
                  displayName: "Install dependencies"
                },
                {
                  script: "npx playwright install --with-deps",
                  displayName: "Install Playwright browsers"
                },
                {
                  script: "npm run test:e2e:ci",
                  displayName: "Run E2E tests"
                },
                {
                  task: "PublishTestResults@2",
                  inputs: {
                    testResultsFormat: "JUnit",
                    testResultsFiles: "test-results/junit.xml"
                  }
                }
              ]
            }
          ]
        }
      ]
    }
  };
}

function getDefaultTestPatterns(): string {
  return `# Common Test Patterns

## Page Object Pattern
class LoginPage extends BasePage {
  private selectors = {
    emailInput: '[data-testid="email-input"]',
    passwordInput: '[data-testid="password-input"]',
    submitButton: '[data-testid="submit-button"]',
    errorMessage: '[data-testid="error-message"]'
  };

  async login(email: string, password: string) {
    await this.fillInput(this.selectors.emailInput, email);
    await this.fillInput(this.selectors.passwordInput, password);
    await this.clickElement(this.selectors.submitButton);
  }
}

## Test Data Pattern
export const testData = {
  validUser: {
    email: 'test@company.com',
    password: 'SecurePass123!'
  },
  invalidUser: {
    email: 'invalid@company.com',
    password: 'wrongpass'
  }
};

## API Mocking Pattern
test('should handle API errors', async ({ page }) => {
  await page.route('**/api/login', route => {
    route.fulfill({
      status: 500,
      contentType: 'application/json',
      body: JSON.stringify({ error: 'Internal Server Error' })
    });
  });
  
  // Test error handling
});

## Accessibility Testing Pattern
test('should be accessible', async ({ page }) => {
  const accessibilityScanResults = await new AxeBuilder({ page }).analyze();
  expect(accessibilityScanResults.violations).toEqual([]);
});

## Mobile Testing Pattern
test.describe('Mobile Tests', () => {
  test.use({ viewport: { width: 375, height: 667 } });
  
  test('should work on mobile', async ({ page }) => {
    // Mobile-specific tests
  });
});

## Performance Testing Pattern
test('should load within performance budget', async ({ page }) => {
  const startTime = Date.now();
  await page.goto('/');
  const loadTime = Date.now() - startTime;
  
  expect(loadTime).toBeLessThan(3000); // 3 second budget
});`;
}