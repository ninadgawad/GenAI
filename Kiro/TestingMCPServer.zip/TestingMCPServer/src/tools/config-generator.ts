import * as fs from 'fs-extra';
import * as path from 'path';

export async function generatePlaywrightConfig(
  projectPath: string,
  baseUrl: string = 'http://localhost:3000',
  browsers: string[] = ['chromium', 'firefox', 'webkit']
) {
  try {
    const configContent = `import { defineConfig, devices } from '@playwright/test';

/**
 * @see https://playwright.dev/docs/test-configuration
 */
export default defineConfig({
  testDir: './tests/functional/e2e',
  
  /* Run tests in files in parallel */
  fullyParallel: true,
  
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,
  
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['html', { outputFolder: 'playwright-report' }],
    ['json', { outputFile: 'test-results/results.json' }],
    ['junit', { outputFile: 'test-results/junit.xml' }]
  ],
  
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like \`await page.goto('/')\`. */
    baseURL: '${baseUrl}',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
    
    /* Take screenshot on failure */
    screenshot: 'only-on-failure',
    
    /* Record video on failure */
    video: 'retain-on-failure',
  },

  /* Configure projects for major browsers */
  projects: [
    ${browsers.includes('chromium') ? `{
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },` : ''}
    
    ${browsers.includes('firefox') ? `{
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },` : ''}

    ${browsers.includes('webkit') ? `{
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },` : ''}

    /* Test against mobile viewports. */
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  webServer: {
    command: 'npm start',
    url: '${baseUrl}',
    reuseExistingServer: !process.env.CI,
    timeout: 120 * 1000,
  },
  
  /* Global setup and teardown */
  // globalSetup: require.resolve('./tests/functional/e2e/utils/global-setup.ts'),
  // globalTeardown: require.resolve('./tests/functional/e2e/utils/global-teardown.ts'),
  
  /* Test timeout */
  timeout: 30 * 1000,
  expect: {
    timeout: 5 * 1000
  },
  
  /* Output directories */
  outputDir: 'test-results/',
});`;

    const configPath = path.join(projectPath, 'playwright.config.ts');
    await fs.writeFile(configPath, configContent);

    // Also create a .gitignore entry for test results
    const gitignorePath = path.join(projectPath, '.gitignore');
    const gitignoreAddition = `
# Playwright
/test-results/
/playwright-report/
/playwright/.cache/
`;

    if (await fs.pathExists(gitignorePath)) {
      const existingContent = await fs.readFile(gitignorePath, 'utf8');
      if (!existingContent.includes('# Playwright')) {
        await fs.appendFile(gitignorePath, gitignoreAddition);
      }
    } else {
      await fs.writeFile(gitignorePath, gitignoreAddition);
    }

    return {
      content: [
        {
          type: 'text',
          text: `✅ Playwright configuration generated successfully!

Created:
- playwright.config.ts (Main configuration file)
- Updated .gitignore with Playwright entries

Configuration includes:
- Base URL: ${baseUrl}
- Browsers: ${browsers.join(', ')}
- Test directory: ./tests/functional/e2e
- HTML, JSON, and JUnit reporters
- Mobile device testing
- Automatic dev server startup
- Screenshot and video on failure
- Trace collection on retry

To install Playwright dependencies, run:
npm install @playwright/test
npx playwright install`,
        },
      ],
    };
  } catch (error) {
    throw new Error(`Failed to generate Playwright config: ${error}`);
  }
}