import * as fs from 'fs-extra';
import * as path from 'path';

export async function generateTestScript(projectPath: string) {
  try {
    const packageJsonPath = path.join(projectPath, 'package.json');
    
    // Read existing package.json
    let packageJson: any = {};
    if (await fs.pathExists(packageJsonPath)) {
      packageJson = await fs.readJson(packageJsonPath);
    }

    // Ensure scripts section exists
    if (!packageJson.scripts) {
      packageJson.scripts = {};
    }

    // Add Playwright test scripts
    const newScripts = {
      'test:e2e': 'playwright test',
      'test:e2e:headed': 'playwright test --headed',
      'test:e2e:debug': 'playwright test --debug',
      'test:e2e:ui': 'playwright test --ui',
      'test:e2e:report': 'playwright show-report',
      'test:e2e:install': 'playwright install',
      'test:e2e:codegen': 'playwright codegen localhost:3000',
      'test:e2e:trace': 'playwright test --trace on',
      'test:e2e:mobile': 'playwright test --project="Mobile Chrome"',
      'test:e2e:ci': 'playwright test --reporter=github',
    };

    // Merge new scripts with existing ones
    packageJson.scripts = { ...packageJson.scripts, ...newScripts };

    // Add Playwright dependencies if not present
    if (!packageJson.devDependencies) {
      packageJson.devDependencies = {};
    }

    const playwrightDeps = {
      '@playwright/test': '^1.40.0',
    };

    Object.entries(playwrightDeps).forEach(([dep, version]) => {
      if (!packageJson.devDependencies[dep] && !packageJson.dependencies?.[dep]) {
        packageJson.devDependencies[dep] = version;
      }
    });

    // Write updated package.json
    await fs.writeJson(packageJsonPath, packageJson, { spaces: 2 });

    // Create a test runner script
    const testRunnerContent = `#!/usr/bin/env node

/**
 * Playwright Test Runner Script
 * This script provides convenient commands for running Playwright tests
 */

const { spawn } = require('child_process');
const path = require('path');

const commands = {
  // Basic test commands
  'run': ['playwright', 'test'],
  'headed': ['playwright', 'test', '--headed'],
  'debug': ['playwright', 'test', '--debug'],
  'ui': ['playwright', 'test', '--ui'],
  
  // Reporting
  'report': ['playwright', 'show-report'],
  'trace': ['playwright', 'test', '--trace', 'on'],
  
  // Setup
  'install': ['playwright', 'install'],
  'codegen': ['playwright', 'codegen', 'localhost:3000'],
  
  // Specific browsers
  'chrome': ['playwright', 'test', '--project=chromium'],
  'firefox': ['playwright', 'test', '--project=firefox'],
  'safari': ['playwright', 'test', '--project=webkit'],
  'mobile': ['playwright', 'test', '--project=Mobile Chrome'],
  
  // CI/CD
  'ci': ['playwright', 'test', '--reporter=github'],
  'parallel': ['playwright', 'test', '--workers=4'],
};

function runCommand(cmd, args = []) {
  const child = spawn(cmd, args, {
    stdio: 'inherit',
    shell: true,
    cwd: process.cwd()
  });
  
  child.on('error', (error) => {
    console.error(\`Error: \${error.message}\`);
    process.exit(1);
  });
  
  child.on('close', (code) => {
    process.exit(code);
  });
}

function showHelp() {
  console.log(\`
Playwright Test Runner

Usage: node test-runner.js <command> [options]

Commands:
  run         Run all tests
  headed      Run tests in headed mode (visible browser)
  debug       Run tests in debug mode
  ui          Open Playwright UI mode
  report      Show test report
  trace       Run tests with trace collection
  install     Install Playwright browsers
  codegen     Generate tests using codegen
  chrome      Run tests only in Chrome
  firefox     Run tests only in Firefox
  safari      Run tests only in Safari
  mobile      Run tests only on mobile
  ci          Run tests with CI reporter
  parallel    Run tests in parallel with 4 workers

Examples:
  node test-runner.js run
  node test-runner.js headed
  node test-runner.js debug login.spec.ts
  node test-runner.js chrome --grep "should login"
  \`);
}

const command = process.argv[2];
const additionalArgs = process.argv.slice(3);

if (!command || command === 'help' || command === '--help') {
  showHelp();
  process.exit(0);
}

if (commands[command]) {
  runCommand(commands[command][0], [...commands[command].slice(1), ...additionalArgs]);
} else {
  console.error(\`Unknown command: \${command}\`);
  showHelp();
  process.exit(1);
}`;

    await fs.writeFile(path.join(projectPath, 'test-runner.js'), testRunnerContent);

    // Create GitHub Actions workflow for CI
    const workflowDir = path.join(projectPath, '.github', 'workflows');
    await fs.ensureDir(workflowDir);

    const workflowContent = `name: Playwright Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    timeout-minutes: 60
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v4
    
    - uses: actions/setup-node@v4
      with:
        node-version: lts/*
        
    - name: Install dependencies
      run: npm ci
      
    - name: Install Playwright Browsers
      run: npx playwright install --with-deps
      
    - name: Run Playwright tests
      run: npm run test:e2e:ci
      
    - uses: actions/upload-artifact@v4
      if: always()
      with:
        name: playwright-report
        path: playwright-report/
        retention-days: 30`;

    await fs.writeFile(path.join(workflowDir, 'playwright.yml'), workflowContent);

    // Create VS Code settings for better development experience
    const vscodeDir = path.join(projectPath, '.vscode');
    await fs.ensureDir(vscodeDir);

    const vscodeSettings = {
      "playwright.reuseBrowser": true,
      "playwright.showTrace": true,
      "files.associations": {
        "*.spec.ts": "typescript"
      },
      "typescript.preferences.includePackageJsonAutoImports": "auto"
    };

    const settingsPath = path.join(vscodeDir, 'settings.json');
    if (await fs.pathExists(settingsPath)) {
      const existingSettings = await fs.readJson(settingsPath);
      Object.assign(existingSettings, vscodeSettings);
      await fs.writeJson(settingsPath, existingSettings, { spaces: 2 });
    } else {
      await fs.writeJson(settingsPath, vscodeSettings, { spaces: 2 });
    }

    return {
      content: [
        {
          type: 'text',
          text: `✅ Test scripts and configuration generated successfully!

Updated package.json with scripts:
- test:e2e - Run all tests
- test:e2e:headed - Run tests with visible browser
- test:e2e:debug - Run tests in debug mode
- test:e2e:ui - Open Playwright UI
- test:e2e:report - Show test report
- test:e2e:install - Install Playwright browsers
- test:e2e:codegen - Generate tests using codegen
- test:e2e:trace - Run tests with trace collection
- test:e2e:mobile - Run mobile tests only
- test:e2e:ci - Run tests with CI reporter

Created files:
- test-runner.js (Convenient test runner script)
- .github/workflows/playwright.yml (CI/CD workflow)
- .vscode/settings.json (VS Code configuration)

To get started:
1. npm install
2. npm run test:e2e:install
3. npm run test:e2e

For development:
- npm run test:e2e:headed (see tests run)
- npm run test:e2e:debug (debug tests)
- npm run test:e2e:ui (interactive UI)
- node test-runner.js codegen (generate new tests)`,
        },
      ],
    };
  } catch (error) {
    throw new Error(`Failed to generate test scripts: ${error}`);
  }
}