import * as fs from 'fs-extra';
import * as path from 'path';

export async function setupTestStructure(projectPath: string) {
  try {
    const testDir = path.join(projectPath, 'tests', 'functional', 'e2e');
    
    // Create directory structure
    await fs.ensureDir(testDir);
    await fs.ensureDir(path.join(testDir, 'fixtures'));
    await fs.ensureDir(path.join(testDir, 'utils'));
    await fs.ensureDir(path.join(testDir, 'pages'));
    
    // Create basic utility files
    const utilsContent = `// Test utilities for Playwright tests
export class TestUtils {
  static async waitForReactApp(page: any) {
    // Wait for React app to be ready
    await page.waitForSelector('[data-testid="app-ready"], #root', { timeout: 10000 });
  }

  static async takeScreenshot(page: any, name: string) {
    await page.screenshot({ path: \`tests/functional/e2e/screenshots/\${name}.png\` });
  }

  static generateTestData() {
    return {
      email: \`test\${Date.now()}@example.com\`,
      username: \`user\${Date.now()}\`,
      password: 'TestPassword123!',
    };
  }
}`;

    await fs.writeFile(path.join(testDir, 'utils', 'test-utils.ts'), utilsContent);

    // Create base page object
    const basePageContent = `import { Page } from '@playwright/test';

export class BasePage {
  constructor(protected page: Page) {}

  async goto(url: string) {
    await this.page.goto(url);
  }

  async waitForPageLoad() {
    await this.page.waitForLoadState('networkidle');
  }

  async clickElement(selector: string) {
    await this.page.click(selector);
  }

  async fillInput(selector: string, value: string) {
    await this.page.fill(selector, value);
  }

  async getText(selector: string): Promise<string> {
    return await this.page.textContent(selector) || '';
  }

  async isVisible(selector: string): Promise<boolean> {
    return await this.page.isVisible(selector);
  }
}`;

    await fs.writeFile(path.join(testDir, 'pages', 'base-page.ts'), basePageContent);

    // Create fixtures directory with sample data
    const fixturesContent = `// Sample test fixtures
export const testData = {
  users: {
    validUser: {
      email: 'test@example.com',
      password: 'password123',
      username: 'testuser'
    },
    invalidUser: {
      email: 'invalid@example.com',
      password: 'wrongpassword'
    }
  },
  
  products: {
    sampleProduct: {
      name: 'Test Product',
      price: 29.99,
      description: 'A test product for e2e testing'
    }
  }
};`;

    await fs.writeFile(path.join(testDir, 'fixtures', 'test-data.ts'), fixturesContent);

    // Create screenshots directory
    await fs.ensureDir(path.join(testDir, 'screenshots'));

    return {
      content: [
        {
          type: 'text',
          text: `✅ Test structure created successfully at ${testDir}

Created directories:
- tests/functional/e2e/
- tests/functional/e2e/fixtures/
- tests/functional/e2e/utils/
- tests/functional/e2e/pages/
- tests/functional/e2e/screenshots/

Created files:
- utils/test-utils.ts (Common test utilities)
- pages/base-page.ts (Base page object model)
- fixtures/test-data.ts (Test data fixtures)

The structure is ready for your Playwright tests!`,
        },
      ],
    };
  } catch (error) {
    throw new Error(`Failed to setup test structure: ${error}`);
  }
}