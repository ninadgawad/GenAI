import * as fs from 'fs-extra';
import * as path from 'path';

export async function generateTestCase(
  projectPath: string,
  testName: string,
  componentName: string,
  testType: string,
  testScenarios: string[] = []
) {
  try {
    const testDir = path.join(projectPath, 'tests', 'functional', 'e2e');
    
    // Generate test content based on type
    let testContent = '';
    
    switch (testType) {
      case 'page':
        testContent = generatePageTest(testName, componentName, testScenarios);
        break;
      case 'component':
        testContent = generateComponentTest(testName, componentName, testScenarios);
        break;
      case 'form':
        testContent = generateFormTest(testName, componentName, testScenarios);
        break;
      case 'navigation':
        testContent = generateNavigationTest(testName, componentName, testScenarios);
        break;
      case 'api':
        testContent = generateApiTest(testName, componentName, testScenarios);
        break;
      default:
        testContent = generateGenericTest(testName, componentName, testScenarios);
    }

    // Create page object if it doesn't exist
    const pageObjectPath = path.join(testDir, 'pages', `${componentName.toLowerCase()}-page.ts`);
    if (!await fs.pathExists(pageObjectPath)) {
      const pageObjectContent = generatePageObject(componentName);
      await fs.writeFile(pageObjectPath, pageObjectContent);
    }

    // Write test file
    const testFileName = `${testName.toLowerCase().replace(/\s+/g, '-')}.spec.ts`;
    const testFilePath = path.join(testDir, testFileName);
    await fs.writeFile(testFilePath, testContent);

    return {
      content: [
        {
          type: 'text',
          text: `✅ Test case generated successfully!

Created:
- ${testFileName} (Test file)
- ${componentName.toLowerCase()}-page.ts (Page object model)

Test type: ${testType}
Component: ${componentName}
Scenarios: ${testScenarios.length > 0 ? testScenarios.join(', ') : 'Default scenarios'}

To run this test:
npx playwright test ${testFileName}
npx playwright test ${testFileName} --headed
npx playwright test ${testFileName} --debug`,
        },
      ],
    };
  } catch (error) {
    throw new Error(`Failed to generate test case: ${error}`);
  }
}

function generatePageTest(testName: string, componentName: string, scenarios: string[]): string {
  const defaultScenarios = scenarios.length > 0 ? scenarios : [
    'should load the page successfully',
    'should display main content',
    'should be responsive on mobile devices'
  ];

  return `import { test, expect } from '@playwright/test';
import { ${componentName}Page } from './pages/${componentName.toLowerCase()}-page';
import { TestUtils } from './utils/test-utils';

test.describe('${testName}', () => {
  let ${componentName.toLowerCase()}Page: ${componentName}Page;

  test.beforeEach(async ({ page }) => {
    ${componentName.toLowerCase()}Page = new ${componentName}Page(page);
    await ${componentName.toLowerCase()}Page.goto('/');
    await TestUtils.waitForReactApp(page);
  });

${defaultScenarios.map(scenario => `
  test('${scenario}', async ({ page }) => {
    // Test implementation for: ${scenario}
    await expect(page).toHaveTitle(/${componentName}/);
    
    // Add your test steps here
    // Example: await ${componentName.toLowerCase()}Page.clickElement('[data-testid="main-button"]');
    // Example: await expect(page.locator('[data-testid="content"]')).toBeVisible();
    
    await TestUtils.takeScreenshot(page, '${scenario.replace(/\s+/g, '-')}');
  });`).join('')}

  test('should handle errors gracefully', async ({ page }) => {
    // Test error handling
    await page.route('**/api/**', route => route.abort());
    await ${componentName.toLowerCase()}Page.goto('/');
    
    // Verify error state
    await expect(page.locator('[data-testid="error-message"]')).toBeVisible();
  });
});`;
}

function generateComponentTest(testName: string, componentName: string, scenarios: string[]): string {
  const defaultScenarios = scenarios.length > 0 ? scenarios : [
    'should render component correctly',
    'should handle user interactions',
    'should display proper states'
  ];

  return `import { test, expect } from '@playwright/test';
import { ${componentName}Page } from './pages/${componentName.toLowerCase()}-page';

test.describe('${testName} - ${componentName} Component', () => {
  let ${componentName.toLowerCase()}Page: ${componentName}Page;

  test.beforeEach(async ({ page }) => {
    ${componentName.toLowerCase()}Page = new ${componentName}Page(page);
    await ${componentName.toLowerCase()}Page.goto('/');
  });

${defaultScenarios.map(scenario => `
  test('${scenario}', async ({ page }) => {
    // Test implementation for: ${scenario}
    const component = page.locator('[data-testid="${componentName.toLowerCase()}"]');
    await expect(component).toBeVisible();
    
    // Add component-specific test steps here
    // Example: await component.click();
    // Example: await expect(component).toHaveClass('active');
  });`).join('')}

  test('should be accessible', async ({ page }) => {
    // Accessibility testing
    const component = page.locator('[data-testid="${componentName.toLowerCase()}"]');
    await expect(component).toBeVisible();
    
    // Check for proper ARIA attributes
    // await expect(component).toHaveAttribute('aria-label');
    // await expect(component).toHaveAttribute('role');
  });
});`;
}

function generateFormTest(testName: string, componentName: string, scenarios: string[]): string {
  const defaultScenarios = scenarios.length > 0 ? scenarios : [
    'should submit form with valid data',
    'should show validation errors for invalid data',
    'should handle form reset'
  ];

  return `import { test, expect } from '@playwright/test';
import { ${componentName}Page } from './pages/${componentName.toLowerCase()}-page';
import { testData } from './fixtures/test-data';

test.describe('${testName} - ${componentName} Form', () => {
  let ${componentName.toLowerCase()}Page: ${componentName}Page;

  test.beforeEach(async ({ page }) => {
    ${componentName.toLowerCase()}Page = new ${componentName}Page(page);
    await ${componentName.toLowerCase()}Page.goto('/');
  });

${defaultScenarios.map(scenario => `
  test('${scenario}', async ({ page }) => {
    // Test implementation for: ${scenario}
    const form = page.locator('[data-testid="${componentName.toLowerCase()}-form"]');
    await expect(form).toBeVisible();
    
    if ('${scenario}'.includes('valid data')) {
      // Fill form with valid data
      await ${componentName.toLowerCase()}Page.fillInput('[name="email"]', testData.users.validUser.email);
      await ${componentName.toLowerCase()}Page.fillInput('[name="password"]', testData.users.validUser.password);
      await ${componentName.toLowerCase()}Page.clickElement('[type="submit"]');
      
      // Verify success
      await expect(page.locator('[data-testid="success-message"]')).toBeVisible();
    }
    
    if ('${scenario}'.includes('validation errors')) {
      // Submit empty form
      await ${componentName.toLowerCase()}Page.clickElement('[type="submit"]');
      
      // Verify validation errors
      await expect(page.locator('[data-testid="error-message"]')).toBeVisible();
    }
  });`).join('')}

  test('should handle form submission loading state', async ({ page }) => {
    // Slow down network to test loading state
    await page.route('**/api/**', route => {
      setTimeout(() => route.continue(), 2000);
    });
    
    await ${componentName.toLowerCase()}Page.fillInput('[name="email"]', testData.users.validUser.email);
    await ${componentName.toLowerCase()}Page.clickElement('[type="submit"]');
    
    // Verify loading state
    await expect(page.locator('[data-testid="loading-spinner"]')).toBeVisible();
  });
});`;
}

function generateNavigationTest(testName: string, componentName: string, scenarios: string[]): string {
  const defaultScenarios = scenarios.length > 0 ? scenarios : [
    'should navigate between pages',
    'should highlight active navigation items',
    'should work on mobile devices'
  ];

  return `import { test, expect } from '@playwright/test';
import { ${componentName}Page } from './pages/${componentName.toLowerCase()}-page';

test.describe('${testName} - ${componentName} Navigation', () => {
  let ${componentName.toLowerCase()}Page: ${componentName}Page;

  test.beforeEach(async ({ page }) => {
    ${componentName.toLowerCase()}Page = new ${componentName}Page(page);
    await ${componentName.toLowerCase()}Page.goto('/');
  });

${defaultScenarios.map(scenario => `
  test('${scenario}', async ({ page }) => {
    // Test implementation for: ${scenario}
    const navigation = page.locator('[data-testid="navigation"]');
    await expect(navigation).toBeVisible();
    
    if ('${scenario}'.includes('navigate between pages')) {
      // Test navigation links
      await ${componentName.toLowerCase()}Page.clickElement('[data-testid="nav-home"]');
      await expect(page).toHaveURL(/.*home/);
      
      await ${componentName.toLowerCase()}Page.clickElement('[data-testid="nav-about"]');
      await expect(page).toHaveURL(/.*about/);
    }
    
    if ('${scenario}'.includes('active navigation')) {
      // Test active state
      await ${componentName.toLowerCase()}Page.clickElement('[data-testid="nav-home"]');
      await expect(page.locator('[data-testid="nav-home"]')).toHaveClass(/active/);
    }
  });`).join('')}

  test('should work with keyboard navigation', async ({ page }) => {
    // Test keyboard accessibility
    await page.keyboard.press('Tab');
    await expect(page.locator('[data-testid="nav-home"]')).toBeFocused();
    
    await page.keyboard.press('Enter');
    await expect(page).toHaveURL(/.*home/);
  });
});`;
}

function generateApiTest(testName: string, componentName: string, scenarios: string[]): string {
  const defaultScenarios = scenarios.length > 0 ? scenarios : [
    'should handle successful API responses',
    'should handle API errors gracefully',
    'should show loading states during API calls'
  ];

  return `import { test, expect } from '@playwright/test';
import { ${componentName}Page } from './pages/${componentName.toLowerCase()}-page';

test.describe('${testName} - ${componentName} API Integration', () => {
  let ${componentName.toLowerCase()}Page: ${componentName}Page;

  test.beforeEach(async ({ page }) => {
    ${componentName.toLowerCase()}Page = new ${componentName}Page(page);
  });

${defaultScenarios.map(scenario => `
  test('${scenario}', async ({ page }) => {
    if ('${scenario}'.includes('successful API')) {
      // Mock successful API response
      await page.route('**/api/**', route => {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: [] })
        });
      });
    }
    
    if ('${scenario}'.includes('API errors')) {
      // Mock API error
      await page.route('**/api/**', route => {
        route.fulfill({
          status: 500,
          contentType: 'application/json',
          body: JSON.stringify({ error: 'Internal Server Error' })
        });
      });
    }
    
    if ('${scenario}'.includes('loading states')) {
      // Mock slow API response
      await page.route('**/api/**', route => {
        setTimeout(() => {
          route.fulfill({
            status: 200,
            contentType: 'application/json',
            body: JSON.stringify({ success: true, data: [] })
          });
        }, 2000);
      });
    }
    
    await ${componentName.toLowerCase()}Page.goto('/');
    
    // Add specific assertions based on scenario
    // Example: await expect(page.locator('[data-testid="data-list"]')).toBeVisible();
  });`).join('')}

  test('should retry failed API calls', async ({ page }) => {
    let callCount = 0;
    await page.route('**/api/**', route => {
      callCount++;
      if (callCount < 3) {
        route.fulfill({ status: 500 });
      } else {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: [] })
        });
      }
    });
    
    await ${componentName.toLowerCase()}Page.goto('/');
    // Verify eventual success after retries
  });
});`;
}

function generateGenericTest(testName: string, componentName: string, scenarios: string[]): string {
  const defaultScenarios = scenarios.length > 0 ? scenarios : [
    'should render correctly',
    'should handle user interactions',
    'should be responsive'
  ];

  return `import { test, expect } from '@playwright/test';
import { ${componentName}Page } from './pages/${componentName.toLowerCase()}-page';

test.describe('${testName}', () => {
  let ${componentName.toLowerCase()}Page: ${componentName}Page;

  test.beforeEach(async ({ page }) => {
    ${componentName.toLowerCase()}Page = new ${componentName}Page(page);
    await ${componentName.toLowerCase()}Page.goto('/');
  });

${defaultScenarios.map(scenario => `
  test('${scenario}', async ({ page }) => {
    // Test implementation for: ${scenario}
    // Add your test steps here
    await expect(page).toHaveTitle(/${componentName}/);
  });`).join('')}
});`;
}

function generatePageObject(componentName: string): string {
  return `import { Page } from '@playwright/test';
import { BasePage } from './base-page';

export class ${componentName}Page extends BasePage {
  constructor(page: Page) {
    super(page);
  }

  // Page-specific selectors
  private selectors = {
    mainContainer: '[data-testid="${componentName.toLowerCase()}-container"]',
    title: '[data-testid="${componentName.toLowerCase()}-title"]',
    content: '[data-testid="${componentName.toLowerCase()}-content"]',
    button: '[data-testid="${componentName.toLowerCase()}-button"]',
    form: '[data-testid="${componentName.toLowerCase()}-form"]',
    input: '[data-testid="${componentName.toLowerCase()}-input"]',
  };

  // Page-specific methods
  async getTitle(): Promise<string> {
    return await this.getText(this.selectors.title);
  }

  async clickMainButton(): Promise<void> {
    await this.clickElement(this.selectors.button);
  }

  async fillMainInput(value: string): Promise<void> {
    await this.fillInput(this.selectors.input, value);
  }

  async isMainContainerVisible(): Promise<boolean> {
    return await this.isVisible(this.selectors.mainContainer);
  }

  async submitForm(): Promise<void> {
    await this.clickElement('[type="submit"]');
  }

  async waitForContent(): Promise<void> {
    await this.page.waitForSelector(this.selectors.content);
  }
}`;
}