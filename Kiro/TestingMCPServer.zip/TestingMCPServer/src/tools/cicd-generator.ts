import * as fs from 'fs-extra';
import * as path from 'path';

interface CustomConfig {
  nodeVersion?: string;
  testTimeout?: number;
  parallelJobs?: number;
  browsers?: string[];
  notifications?: any;
  deploymentStages?: string[];
  [key: string]: any;
}

export async function generateCicdConfig(
  projectPath: string,
  cicdPlatform: string,
  companyStandardsPath?: string,
  customConfig: CustomConfig = {}
) {
  try {
    let companyStandards: any = {};
    
    // Load company standards if provided
    if (companyStandardsPath && await fs.pathExists(companyStandardsPath)) {
      const standardsContent = await fs.readFile(companyStandardsPath, 'utf8');
      companyStandards = parseCompanyStandards(standardsContent);
    }

    // Merge company standards with custom config
    const config = {
      nodeVersion: '18',
      testTimeout: 30,
      parallelJobs: 4,
      browsers: ['chromium', 'firefox', 'webkit'],
      deploymentStages: ['dev', 'staging', 'production'],
      ...companyStandards,
      ...customConfig
    };

    let configContent = '';
    let configFileName = '';

    switch (cicdPlatform) {
      case 'jenkins':
        configContent = generateJenkinsConfig(config);
        configFileName = 'Jenkinsfile';
        break;
      case 'gitlab':
        configContent = generateGitLabConfig(config);
        configFileName = '.gitlab-ci.yml';
        break;
      case 'azure-devops':
        configContent = generateAzureDevOpsConfig(config);
        configFileName = 'azure-pipelines.yml';
        break;
      case 'github-actions':
        configContent = generateGitHubActionsConfig(config);
        configFileName = '.github/workflows/playwright.yml';
        break;
      case 'circleci':
        configContent = generateCircleCIConfig(config);
        configFileName = '.circleci/config.yml';
        break;
      case 'travis':
        configContent = generateTravisConfig(config);
        configFileName = '.travis.yml';
        break;
      default:
        throw new Error(`Unsupported CI/CD platform: ${cicdPlatform}`);
    }

    // Create directory if needed
    const configDir = path.dirname(path.join(projectPath, configFileName));
    await fs.ensureDir(configDir);

    // Write configuration file
    await fs.writeFile(path.join(projectPath, configFileName), configContent);

    // Generate additional configuration files
    await generateAdditionalConfigs(projectPath, cicdPlatform, config);

    return {
      content: [
        {
          type: 'text',
          text: `✅ ${cicdPlatform} CI/CD configuration generated successfully!

Created:
- ${configFileName} (Main CI/CD configuration)
- Additional configuration files for ${cicdPlatform}

Configuration includes:
- Node.js version: ${config.nodeVersion}
- Test timeout: ${config.testTimeout}s
- Parallel jobs: ${config.parallelJobs}
- Browsers: ${config.browsers.join(', ')}
- Deployment stages: ${config.deploymentStages.join(', ')}

Platform-specific features:
${getPlatformFeatures(cicdPlatform)}

Next steps:
1. Review and customize the generated configuration
2. Set up environment variables and secrets
3. Configure deployment targets
4. Test the pipeline with a sample commit`,
        },
      ],
    };
  } catch (error) {
    throw new Error(`Failed to generate CI/CD config: ${error}`);
  }
}

function parseCompanyStandards(content: string): any {
  // Simple parser for markdown-based company standards
  const standards: any = {};
  
  // Extract configuration from markdown
  const nodeVersionMatch = content.match(/Node\.js version:\s*(\d+)/i);
  if (nodeVersionMatch) {
    standards.nodeVersion = nodeVersionMatch[1];
  }
  
  const timeoutMatch = content.match(/Test timeout:\s*(\d+)/i);
  if (timeoutMatch) {
    standards.testTimeout = parseInt(timeoutMatch[1]);
  }
  
  const browsersMatch = content.match(/Required browsers:\s*\n((?:- .+\n?)+)/i);
  if (browsersMatch) {
    standards.browsers = browsersMatch[1]
      .split('\n')
      .filter(line => line.trim().startsWith('-'))
      .map(line => line.replace(/^-\s*/, '').trim().toLowerCase());
  }
  
  return standards;
}

function generateJenkinsConfig(config: any): string {
  return `pipeline {
    agent any
    
    environment {
        NODE_VERSION = '${config.nodeVersion}'
        PLAYWRIGHT_BROWSERS_PATH = '$WORKSPACE/browsers'
        CI = 'true'
    }
    
    options {
        timeout(time: ${config.testTimeout + 10}, unit: 'MINUTES')
        retry(2)
        skipStagesAfterUnstable()
    }
    
    stages {
        stage('Checkout') {
            steps {
                checkout scm
                script {
                    env.GIT_COMMIT_SHORT = sh(
                        script: "git rev-parse --short HEAD",
                        returnStdout: true
                    ).trim()
                }
            }
        }
        
        stage('Setup') {
            parallel {
                stage('Install Dependencies') {
                    steps {
                        sh '''
                            nvm use $NODE_VERSION
                            npm ci --prefer-offline --no-audit
                        '''
                    }
                }
                stage('Install Browsers') {
                    steps {
                        sh '''
                            npx playwright install --with-deps ${config.browsers.join(' ')}
                        '''
                    }
                }
            }
        }
        
        stage('Code Quality') {
            parallel {
                stage('Lint') {
                    steps {
                        sh 'npm run lint'
                    }
                    post {
                        always {
                            publishHTML([
                                allowMissing: false,
                                alwaysLinkToLastBuild: true,
                                keepAll: true,
                                reportDir: 'lint-results',
                                reportFiles: 'index.html',
                                reportName: 'ESLint Report'
                            ])
                        }
                    }
                }
                stage('Type Check') {
                    steps {
                        sh 'npm run type-check'
                    }
                }
                stage('Security Scan') {
                    steps {
                        sh 'npm audit --audit-level moderate'
                    }
                }
            }
        }
        
        stage('Unit Tests') {
            steps {
                sh 'npm run test:unit -- --coverage'
            }
            post {
                always {
                    publishTestResults testResultsPattern: 'test-results/unit/junit.xml'
                    publishHTML([
                        allowMissing: false,
                        alwaysLinkToLastBuild: true,
                        keepAll: true,
                        reportDir: 'coverage',
                        reportFiles: 'index.html',
                        reportName: 'Coverage Report'
                    ])
                }
            }
        }
        
        stage('Build') {
            steps {
                sh 'npm run build'
            }
            post {
                success {
                    archiveArtifacts artifacts: 'dist/**/*', fingerprint: true
                }
            }
        }
        
        stage('E2E Tests') {
            steps {
                sh '''
                    npm start &
                    APP_PID=$!
                    echo $APP_PID > app.pid
                    
                    # Wait for app to be ready
                    timeout 60 bash -c 'until curl -f http://localhost:3000; do sleep 2; done'
                    
                    # Run tests
                    npm run test:e2e:ci -- --workers=${config.parallelJobs}
                '''
            }
            post {
                always {
                    sh '''
                        if [ -f app.pid ]; then
                            kill $(cat app.pid) || true
                            rm app.pid
                        fi
                    '''
                    publishTestResults testResultsPattern: 'test-results/junit.xml'
                    publishHTML([
                        allowMissing: false,
                        alwaysLinkToLastBuild: true,
                        keepAll: true,
                        reportDir: 'playwright-report',
                        reportFiles: 'index.html',
                        reportName: 'Playwright Report'
                    ])
                    archiveArtifacts artifacts: 'test-results/**/*', allowEmptyArchive: true
                }
            }
        }
        
        ${config.deploymentStages.map((stage: string) => `
        stage('Deploy to ${stage}') {
            when {
                anyOf {
                    branch 'main'
                    branch 'develop'
                    ${stage === 'production' ? "tag pattern: 'v\\\\d+\\\\.\\\\d+\\\\.\\\\d+', comparator: 'REGEXP'" : ''}
                }
            }
            steps {
                script {
                    if ('${stage}' == 'production' && env.BRANCH_NAME != 'main') {
                        error('Production deployment only allowed from main branch')
                    }
                }
                sh '''
                    echo "Deploying to ${stage} environment"
                    # Add your deployment commands here
                '''
            }
        }`).join('')}
    }
    
    post {
        always {
            cleanWs()
        }
        success {
            ${config.notifications?.slack ? `
            slackSend(
                channel: '${config.notifications.slack.channel}',
                color: 'good',
                message: "✅ Pipeline succeeded for \${env.JOB_NAME} - \${env.BUILD_NUMBER}"
            )` : ''}
        }
        failure {
            ${config.notifications?.slack ? `
            slackSend(
                channel: '${config.notifications.slack.channel}',
                color: 'danger',
                message: "❌ Pipeline failed for \${env.JOB_NAME} - \${env.BUILD_NUMBER}"
            )` : ''}
        }
    }
}`;
}

function generateGitLabConfig(config: any): string {
  return `# GitLab CI/CD Configuration for React.js with Playwright
image: node:${config.nodeVersion}

variables:
  NODE_ENV: "test"
  PLAYWRIGHT_BROWSERS_PATH: "$CI_PROJECT_DIR/browsers"
  CI: "true"

stages:
  - install
  - quality
  - test
  - build
  - deploy

cache:
  key: \${CI_COMMIT_REF_SLUG}
  paths:
    - node_modules/
    - browsers/
    - .npm/

.install_template: &install_template
  before_script:
    - npm ci --cache .npm --prefer-offline --no-audit
    - npx playwright install --with-deps ${config.browsers.join(' ')}

install:
  stage: install
  script:
    - npm ci --cache .npm --prefer-offline --no-audit
    - npx playwright install --with-deps ${config.browsers.join(' ')}
  artifacts:
    paths:
      - node_modules/
      - browsers/
    expire_in: 1 hour

lint:
  stage: quality
  <<: *install_template
  script:
    - npm run lint
    - npm run type-check
  artifacts:
    reports:
      codequality: lint-results.json
    expire_in: 1 week

security:
  stage: quality
  <<: *install_template
  script:
    - npm audit --audit-level moderate
  allow_failure: true

unit-tests:
  stage: test
  <<: *install_template
  script:
    - npm run test:unit -- --coverage
  artifacts:
    reports:
      junit: test-results/unit/junit.xml
      coverage_report:
        coverage_format: cobertura
        path: coverage/cobertura-coverage.xml
    paths:
      - coverage/
    expire_in: 1 week
  coverage: '/Lines\\s*:\\s*(\\d+\\.?\\d*)%/'

e2e-tests:
  stage: test
  <<: *install_template
  script:
    - npm run build
    - npm start &
    - sleep 30
    - npm run test:e2e:ci -- --workers=${config.parallelJobs}
  artifacts:
    when: always
    reports:
      junit: test-results/junit.xml
    paths:
      - playwright-report/
      - test-results/
    expire_in: 1 week
  timeout: ${config.testTimeout + 5} minutes

build:
  stage: build
  <<: *install_template
  script:
    - npm run build
  artifacts:
    paths:
      - dist/
    expire_in: 1 week
  only:
    - main
    - develop
    - tags

${config.deploymentStages.map((stage: string) => `
deploy-${stage}:
  stage: deploy
  script:
    - echo "Deploying to ${stage} environment"
    # Add your deployment commands here
  environment:
    name: ${stage}
    url: https://${stage}.yourapp.com
  only:
    - ${stage === 'production' ? 'main' : 'develop'}
  when: manual
  ${stage === 'production' ? 'only:\n    - tags' : ''}
`).join('')}

# Include additional GitLab CI templates
include:
  - template: Security/SAST.gitlab-ci.yml
  - template: Security/Dependency-Scanning.gitlab-ci.yml`;
}

function generateGitHubActionsConfig(config: any): string {
  return `name: Playwright Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]
  schedule:
    - cron: '0 2 * * *' # Daily at 2 AM

env:
  NODE_VERSION: ${config.nodeVersion}
  CI: true

jobs:
  test:
    timeout-minutes: ${config.testTimeout + 10}
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        browser: [${config.browsers.map((b: string) => `'${b}'`).join(', ')}]
      fail-fast: false
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
      
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: \${{ env.NODE_VERSION }}
        cache: 'npm'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Install Playwright Browsers
      run: npx playwright install --with-deps \${{ matrix.browser }}
      
    - name: Lint and type check
      run: |
        npm run lint
        npm run type-check
        
    - name: Run unit tests
      run: npm run test:unit -- --coverage
      
    - name: Build application
      run: npm run build
      
    - name: Run Playwright tests
      run: npm run test:e2e:ci -- --project=\${{ matrix.browser }} --workers=${config.parallelJobs}
      
    - name: Upload test results
      uses: actions/upload-artifact@v4
      if: always()
      with:
        name: playwright-report-\${{ matrix.browser }}
        path: |
          playwright-report/
          test-results/
        retention-days: 30
        
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      if: matrix.browser == 'chromium'
      with:
        file: ./coverage/lcov.info
        flags: unittests
        name: codecov-umbrella

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    
    strategy:
      matrix:
        environment: [${config.deploymentStages.map((s: string) => `'${s}'`).join(', ')}]
    
    environment:
      name: \${{ matrix.environment }}
      url: https://\${{ matrix.environment }}.yourapp.com
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
      
    - name: Deploy to \${{ matrix.environment }}
      run: |
        echo "Deploying to \${{ matrix.environment }} environment"
        # Add your deployment commands here`;
}

function generateAzureDevOpsConfig(config: any): string {
  return `# Azure DevOps Pipeline for React.js with Playwright
trigger:
  branches:
    include:
      - main
      - develop
  tags:
    include:
      - v*

pr:
  branches:
    include:
      - main
      - develop

pool:
  vmImage: 'ubuntu-latest'

variables:
  nodeVersion: '${config.nodeVersion}.x'
  CI: true

stages:
- stage: Test
  displayName: 'Test Stage'
  jobs:
  - job: E2ETests
    displayName: 'E2E Tests'
    timeoutInMinutes: ${config.testTimeout + 10}
    
    strategy:
      matrix:
        ${config.browsers.map((browser: string) => `
        ${browser}:
          browserName: '${browser}'`).join('')}
    
    steps:
    - task: NodeTool@0
      inputs:
        versionSpec: '\$(nodeVersion)'
      displayName: 'Install Node.js'
      
    - task: Cache@2
      inputs:
        key: 'npm | "\$(Agent.OS)" | package-lock.json'
        restoreKeys: |
          npm | "\$(Agent.OS)"
        path: \$(npm config get cache)
      displayName: 'Cache npm'
      
    - script: npm ci
      displayName: 'Install dependencies'
      
    - script: npx playwright install --with-deps \$(browserName)
      displayName: 'Install Playwright browsers'
      
    - script: |
        npm run lint
        npm run type-check
      displayName: 'Code quality checks'
      
    - script: npm run test:unit -- --coverage
      displayName: 'Run unit tests'
      
    - script: npm run build
      displayName: 'Build application'
      
    - script: npm run test:e2e:ci -- --project=\$(browserName) --workers=${config.parallelJobs}
      displayName: 'Run E2E tests'
      
    - task: PublishTestResults@2
      condition: always()
      inputs:
        testResultsFormat: 'JUnit'
        testResultsFiles: 'test-results/junit.xml'
        testRunTitle: 'Playwright Tests - \$(browserName)'
      displayName: 'Publish test results'
      
    - task: PublishHtmlReport@1
      condition: always()
      inputs:
        reportDir: 'playwright-report'
        tabName: 'Playwright Report - \$(browserName)'
      displayName: 'Publish HTML report'

- stage: Deploy
  displayName: 'Deploy Stage'
  dependsOn: Test
  condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
  
  jobs:
  ${config.deploymentStages.map((stage: string) => `
  - deployment: Deploy${stage.charAt(0).toUpperCase() + stage.slice(1)}
    displayName: 'Deploy to ${stage}'
    environment: '${stage}'
    strategy:
      runOnce:
        deploy:
          steps:
          - script: |
              echo "Deploying to ${stage} environment"
              # Add your deployment commands here
            displayName: 'Deploy to ${stage}'`).join('')}`;
}

function generateCircleCIConfig(config: any): string {
  return `version: 2.1

orbs:
  node: circleci/node@5.0.0
  browser-tools: circleci/browser-tools@1.4.0

executors:
  node-executor:
    docker:
      - image: cimg/node:${config.nodeVersion}-browsers
    working_directory: ~/project

jobs:
  install-dependencies:
    executor: node-executor
    steps:
      - checkout
      - node/install-packages:
          pkg-manager: npm
      - run:
          name: Install Playwright browsers
          command: npx playwright install --with-deps ${config.browsers.join(' ')}
      - persist_to_workspace:
          root: ~/project
          paths:
            - node_modules
            - ~/.cache/ms-playwright

  lint-and-typecheck:
    executor: node-executor
    steps:
      - checkout
      - attach_workspace:
          at: ~/project
      - run:
          name: Lint code
          command: npm run lint
      - run:
          name: Type check
          command: npm run type-check

  unit-tests:
    executor: node-executor
    steps:
      - checkout
      - attach_workspace:
          at: ~/project
      - run:
          name: Run unit tests
          command: npm run test:unit -- --coverage
      - store_test_results:
          path: test-results/unit
      - store_artifacts:
          path: coverage

  e2e-tests:
    executor: node-executor
    parallelism: ${config.parallelJobs}
    steps:
      - checkout
      - attach_workspace:
          at: ~/project
      - run:
          name: Build application
          command: npm run build
      - run:
          name: Start application
          command: npm start
          background: true
      - run:
          name: Wait for application
          command: |
            timeout 60 bash -c 'until curl -f http://localhost:3000; do sleep 2; done'
      - run:
          name: Run E2E tests
          command: |
            TESTFILES=\$(circleci tests glob "tests/functional/e2e/**/*.spec.ts" | circleci tests split --split-by=timings)
            npm run test:e2e:ci -- \$TESTFILES --workers=1
      - store_test_results:
          path: test-results
      - store_artifacts:
          path: playwright-report
      - store_artifacts:
          path: test-results

workflows:
  test-and-deploy:
    jobs:
      - install-dependencies
      - lint-and-typecheck:
          requires:
            - install-dependencies
      - unit-tests:
          requires:
            - install-dependencies
      - e2e-tests:
          requires:
            - install-dependencies
            - lint-and-typecheck
            - unit-tests
      ${config.deploymentStages.map((stage: string) => `
      - deploy-${stage}:
          requires:
            - e2e-tests
          filters:
            branches:
              only: ${stage === 'production' ? 'main' : 'develop'}`).join('')}

  ${config.deploymentStages.map((stage: string) => `
  deploy-${stage}:
    executor: node-executor
    steps:
      - checkout
      - run:
          name: Deploy to ${stage}
          command: |
            echo "Deploying to ${stage} environment"
            # Add your deployment commands here`).join('')}`;
}

function generateTravisConfig(config: any): string {
  return `language: node_js
node_js:
  - "${config.nodeVersion}"

os: linux
dist: focal

addons:
  apt:
    packages:
      - libnss3-dev
      - libatk-bridge2.0-dev
      - libdrm2
      - libxkbcommon-dev
      - libxcomposite-dev
      - libxdamage-dev
      - libxrandr2
      - libgbm-dev
      - libxss1
      - libasound2-dev

cache:
  directories:
    - node_modules
    - ~/.cache/ms-playwright

env:
  - CI=true

before_install:
  - npm ci

install:
  - npx playwright install --with-deps ${config.browsers.join(' ')}

script:
  - npm run lint
  - npm run type-check
  - npm run test:unit -- --coverage
  - npm run build
  - npm start &
  - sleep 30
  - npm run test:e2e:ci -- --workers=${config.parallelJobs}

after_success:
  - bash <(curl -s https://codecov.io/bash)

deploy:
  ${config.deploymentStages.map((stage: string) => `
  - provider: script
    script: echo "Deploying to ${stage} environment"
    on:
      branch: ${stage === 'production' ? 'main' : 'develop'}
    skip_cleanup: true`).join('')}

notifications:
  email:
    on_success: change
    on_failure: always`;
}

async function generateAdditionalConfigs(projectPath: string, platform: string, config: any) {
  // Generate Docker configuration for containerized CI/CD
  if (['jenkins', 'gitlab', 'azure-devops'].includes(platform)) {
    const dockerContent = `# Dockerfile for CI/CD
FROM node:${config.nodeVersion}-alpine

# Install dependencies for Playwright
RUN apk add --no-cache \\
    chromium \\
    firefox \\
    webkit2gtk \\
    && rm -rf /var/cache/apk/*

# Set environment variables
ENV PLAYWRIGHT_BROWSERS_PATH=/usr/bin
ENV CI=true

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application code
COPY . .

# Build application
RUN npm run build

# Expose port
EXPOSE 3000

# Start application
CMD ["npm", "start"]`;

    await fs.writeFile(path.join(projectPath, 'Dockerfile.ci'), dockerContent);
  }

  // Generate environment configuration
  const envContent = `# Environment Configuration for CI/CD

# Application
NODE_ENV=test
PORT=3000
BASE_URL=http://localhost:3000

# Testing
PLAYWRIGHT_BROWSERS_PATH=./browsers
TEST_TIMEOUT=${config.testTimeout * 1000}
PARALLEL_WORKERS=${config.parallelJobs}

# CI/CD Platform specific
CI=true
${platform.toUpperCase()}_CI=true

# Database (if applicable)
# DATABASE_URL=postgresql://test:test@localhost:5432/testdb

# External Services (mock in CI)
# API_BASE_URL=http://localhost:3001
# MOCK_EXTERNAL_APIS=true

# Security
# JWT_SECRET=test-secret-key
# ENCRYPTION_KEY=test-encryption-key

# Monitoring and Logging
LOG_LEVEL=info
ENABLE_METRICS=false

# Feature Flags
ENABLE_EXPERIMENTAL_FEATURES=false`;

  await fs.writeFile(path.join(projectPath, '.env.ci'), envContent);

  // Generate test configuration
  const testConfigContent = `# Test Configuration

## Browser Configuration
BROWSERS=${config.browsers.join(',')}
HEADLESS=true
SLOW_MO=0

## Timeouts
DEFAULT_TIMEOUT=${config.testTimeout * 1000}
NAVIGATION_TIMEOUT=30000
ACTION_TIMEOUT=10000

## Screenshots and Videos
SCREENSHOT_ON_FAILURE=true
VIDEO_ON_FAILURE=true
TRACE_ON_RETRY=true

## Parallel Execution
MAX_WORKERS=${config.parallelJobs}
FULLY_PARALLEL=true

## Retry Configuration
RETRIES=2
RETRY_ON_FAILURE=true

## Reporting
HTML_REPORT=true
JSON_REPORT=true
JUNIT_REPORT=true`;

  await fs.writeFile(path.join(projectPath, 'test.config'), testConfigContent);
}

function getPlatformFeatures(platform: string): string {
  const features: { [key: string]: string[] } = {
    jenkins: [
      'Pipeline as Code with Jenkinsfile',
      'Parallel stage execution',
      'HTML report publishing',
      'Artifact archiving',
      'Slack notifications support',
      'Blue Ocean UI compatibility'
    ],
    gitlab: [
      'GitLab CI/CD with YAML configuration',
      'Built-in Docker support',
      'Security scanning integration',
      'Code quality reports',
      'Environment deployments',
      'Merge request pipelines'
    ],
    'azure-devops': [
      'Azure Pipelines YAML',
      'Multi-stage deployments',
      'Test result publishing',
      'HTML report integration',
      'Variable groups support',
      'Environment approvals'
    ],
    'github-actions': [
      'GitHub Actions workflow',
      'Matrix strategy for browsers',
      'Artifact uploads',
      'Codecov integration',
      'Environment deployments',
      'Scheduled runs'
    ],
    circleci: [
      'CircleCI 2.1 configuration',
      'Orb integrations',
      'Parallel test execution',
      'Workspace persistence',
      'Test splitting',
      'Artifact storage'
    ],
    travis: [
      'Travis CI configuration',
      'Multi-OS support',
      'Cache optimization',
      'Codecov integration',
      'Deployment providers',
      'Build notifications'
    ]
  };

  return features[platform]?.map(feature => `- ${feature}`).join('\n') || 'Standard CI/CD features';
}