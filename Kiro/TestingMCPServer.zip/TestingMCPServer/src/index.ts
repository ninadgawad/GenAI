#!/usr/bin/env node

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ListPromptsRequestSchema,
  GetPromptRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { generatePlaywrightConfig } from './tools/config-generator.js';
import { generateTestCase } from './tools/test-generator.js';
import { setupTestStructure } from './tools/structure-setup.js';
import { generateTestScript } from './tools/script-generator.js';
import { generateCicdConfig } from './tools/cicd-generator.js';
import { loadCompanyStandards } from './resources/company-standards.js';

const server = new Server({
  name: 'testing-mcp-server',
  version: '1.0.0',
  capabilities: {
    tools: {},
    resources: {},
    prompts: {},
  },
});

// List available resources
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: 'company-standards://testing-standards',
        name: 'Company Testing Standards',
        description: 'Company-specific testing standards and guidelines',
        mimeType: 'text/markdown',
      },
      {
        uri: 'company-standards://cicd-templates',
        name: 'CI/CD Templates',
        description: 'Pre-configured CI/CD templates for different platforms',
        mimeType: 'application/json',
      },
      {
        uri: 'company-standards://test-patterns',
        name: 'Test Patterns',
        description: 'Approved test patterns and code snippets',
        mimeType: 'text/plain',
      },
    ],
  };
});

// Read resources
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;

  switch (uri) {
    case 'company-standards://testing-standards':
      return {
        contents: [
          {
            uri,
            mimeType: 'text/markdown',
            text: await loadCompanyStandards('testing-standards'),
          },
        ],
      };

    case 'company-standards://cicd-templates':
      return {
        contents: [
          {
            uri,
            mimeType: 'application/json',
            text: await loadCompanyStandards('cicd-templates'),
          },
        ],
      };

    case 'company-standards://test-patterns':
      return {
        contents: [
          {
            uri,
            mimeType: 'text/plain',
            text: await loadCompanyStandards('test-patterns'),
          },
        ],
      };

    default:
      throw new Error(`Unknown resource: ${uri}`);
  }
});

// List available prompts
server.setRequestHandler(ListPromptsRequestSchema, async () => {
  return {
    prompts: [
      {
        name: 'generate_test_with_standards',
        description: 'Generate test cases following company standards',
        arguments: [
          {
            name: 'component_name',
            description: 'Name of the React component to test',
            required: true,
          },
          {
            name: 'test_type',
            description: 'Type of test (page, component, form, navigation, api)',
            required: true,
          },
          {
            name: 'company_standards',
            description: 'Company standards to follow',
            required: false,
          },
        ],
      },
      {
        name: 'setup_cicd_pipeline',
        description: 'Setup CI/CD pipeline with company standards',
        arguments: [
          {
            name: 'platform',
            description: 'CI/CD platform (jenkins, gitlab, azure-devops, etc.)',
            required: true,
          },
          {
            name: 'project_type',
            description: 'Type of project (react, node, fullstack)',
            required: true,
          },
        ],
      },
    ],
  };
});

// Handle prompt requests
server.setRequestHandler(GetPromptRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  switch (name) {
    case 'generate_test_with_standards':
      return {
        description: 'Generate comprehensive test cases following company standards',
        messages: [
          {
            role: 'user',
            content: {
              type: 'text',
              text: `Generate a comprehensive test suite for the ${args?.component_name} component of type ${args?.test_type}. 

Follow these company standards:
${args?.company_standards || 'Use default best practices'}

Include:
1. Proper test structure and naming conventions
2. Accessibility testing requirements
3. Performance testing considerations
4. Error handling and edge cases
5. Mobile responsiveness tests
6. Security testing where applicable

Generate both the test file and corresponding page object model.`,
            },
          },
        ],
      };

    case 'setup_cicd_pipeline':
      return {
        description: 'Setup CI/CD pipeline configuration with company standards',
        messages: [
          {
            role: 'user',
            content: {
              type: 'text',
              text: `Create a complete CI/CD pipeline configuration for ${args?.platform} platform for a ${args?.project_type} project.

Include:
1. Build and test stages
2. Code quality checks (linting, security scanning)
3. Playwright test execution with proper reporting
4. Deployment stages (dev, staging, production)
5. Notification configurations
6. Artifact management
7. Environment-specific configurations
8. Rollback strategies

Follow company security and deployment standards.`,
            },
          },
        ],
      };

    default:
      throw new Error(`Unknown prompt: ${name}`);
  }
});

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: 'setup_test_structure',
        description: 'Creates the test folder structure (tests/functional/e2e) and basic configuration files',
        inputSchema: {
          type: 'object',
          properties: {
            projectPath: {
              type: 'string',
              description: 'Path to the React.js project root',
            },
          },
          required: ['projectPath'],
        },
      },
      {
        name: 'generate_playwright_config',
        description: 'Generates Playwright configuration file tailored for React.js applications',
        inputSchema: {
          type: 'object',
          properties: {
            projectPath: {
              type: 'string',
              description: 'Path to the React.js project root',
            },
            baseUrl: {
              type: 'string',
              description: 'Base URL for the application (default: http://localhost:3000)',
              default: 'http://localhost:3000',
            },
            browsers: {
              type: 'array',
              items: { type: 'string' },
              description: 'Browsers to test on (default: ["chromium", "firefox", "webkit"])',
              default: ['chromium', 'firefox', 'webkit'],
            },
          },
          required: ['projectPath'],
        },
      },
      {
        name: 'generate_test_case',
        description: 'Generates a functional test case for a specific React component or page',
        inputSchema: {
          type: 'object',
          properties: {
            projectPath: {
              type: 'string',
              description: 'Path to the React.js project root',
            },
            testName: {
              type: 'string',
              description: 'Name of the test case',
            },
            componentName: {
              type: 'string',
              description: 'Name of the React component to test',
            },
            testType: {
              type: 'string',
              enum: ['page', 'component', 'form', 'navigation', 'api'],
              description: 'Type of test to generate',
            },
            testScenarios: {
              type: 'array',
              items: { type: 'string' },
              description: 'List of test scenarios to include',
            },
          },
          required: ['projectPath', 'testName', 'componentName', 'testType'],
        },
      },
      {
        name: 'generate_test_script',
        description: 'Generates npm scripts and commands to run Playwright tests',
        inputSchema: {
          type: 'object',
          properties: {
            projectPath: {
              type: 'string',
              description: 'Path to the React.js project root',
            },
          },
          required: ['projectPath'],
        },
      },
      {
        name: 'generate_cicd_config',
        description: 'Generates CI/CD configuration for various platforms (Jenkins, GitLab, Azure DevOps, etc.)',
        inputSchema: {
          type: 'object',
          properties: {
            projectPath: {
              type: 'string',
              description: 'Path to the React.js project root',
            },
            cicdPlatform: {
              type: 'string',
              enum: ['jenkins', 'gitlab', 'azure-devops', 'github-actions', 'circleci', 'travis'],
              description: 'CI/CD platform to generate configuration for',
            },
            companyStandardsPath: {
              type: 'string',
              description: 'Path to company standards markdown file (optional)',
            },
            customConfig: {
              type: 'object',
              description: 'Custom configuration overrides',
              properties: {
                nodeVersion: { type: 'string', default: '18' },
                testTimeout: { type: 'number', default: 30 },
                parallelJobs: { type: 'number', default: 4 },
                browsers: { type: 'array', items: { type: 'string' } },
                notifications: { type: 'object' },
                deploymentStages: { type: 'array', items: { type: 'string' } }
              }
            }
          },
          required: ['projectPath', 'cicdPlatform'],
        },
      },
    ],
  };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    if (!args) {
      throw new Error('Missing arguments');
    }

    const typedArgs = args as any; // Type assertion for MCP arguments

    switch (name) {
      case 'setup_test_structure':
        return await setupTestStructure(typedArgs.projectPath);

      case 'generate_playwright_config':
        return await generatePlaywrightConfig(
          typedArgs.projectPath,
          typedArgs.baseUrl || 'http://localhost:3000',
          typedArgs.browsers || ['chromium', 'firefox', 'webkit']
        );

      case 'generate_test_case':
        return await generateTestCase(
          typedArgs.projectPath,
          typedArgs.testName,
          typedArgs.componentName,
          typedArgs.testType,
          typedArgs.testScenarios || []
        );

      case 'generate_test_script':
        return await generateTestScript(typedArgs.projectPath);

      case 'generate_cicd_config':
        return await generateCicdConfig(
          typedArgs.projectPath,
          typedArgs.cicdPlatform,
          typedArgs.companyStandardsPath,
          typedArgs.customConfig || {}
        );

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (error) {
    return {
      content: [
        {
          type: 'text',
          text: `Error: ${error instanceof Error ? error.message : String(error)}`,
        },
      ],
    };
  }
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('Testing MCP Server running on stdio');
}

main().catch((error) => {
  console.error('Server error:', error);
  process.exit(1);
});